# PULSO.NETWORK — Website Specification
## Marketing website. NOT a landing page. A full site.
### Read UNCODIXFY-PULSO.md before building any page.

---

## PURPOSE

Convince telecom professionals in Brazil to sign up for Pulso. The visitor is Carlos (ISP owner), Fernanda (engineer), Patricia (M&A analyst), Marcos (agro manager), or Ricardo (Trópico sales). They are skeptical. They want to know: does this actually work? Is it for someone like me? What does it cost? The site answers fast, in Portuguese, without hype.

## TECH STACK

Framework: Next.js 14 (App Router, static export). Styling: Tailwind CSS (UNCODIXFY-PULSO colors). Font: IBM Plex Sans (local, not CDN). Images: WebP, lazy loaded, no stock photos. Icons: Lucide React. Analytics: Plausible. Language: pt-BR only.

## SITE MAP

```
pulso.network/
├── /                       Home
├── /produto                Product — what Pulso does
├── /solucoes/provedores    For ISPs
├── /solucoes/redes-privativas  For private networks
├── /solucoes/mna           For M&A
├── /precos                 Pricing
├── /sobre                  About — story, team, mission
├── /contato                Contact
├── /blog                   Future articles
├── /login                  → app.pulso.network
└── /cadastro               Sign up
```

## NAVIGATION (all pages)

Sticky top, 56px height, bg-surface, 1px border-bottom. Pulso logo left. Links: Produto | Soluções (dropdown: Provedores, Redes Privativas, M&A) | Preços | Sobre. CTA button right: "Começar" (accent, → /cadastro). Mobile: hamburger menu.

## HOME (/)

In 10 seconds, visitor understands what Pulso is and who it's for.

Section 1 — Hero: Left text, right real screenshot. Headline (text-2xl semibold): "Inteligência para telecomunicações. Onde expandir. Como projetar. Quanto investir." Subtext (text-base, text-secondary, 2 lines): "Dados abertos da Anatel, IBGE e INPE transformados em decisões para provedores, redes privativas e investidores." Two buttons: "Ver produto" (primary) + "Falar com a equipe" (secondary). Right: REAL screenshot of the map, simple border, 6px radius. Not a mockup. Not an illustration.

Section 2 — Three value propositions: Simple 3-column grid, no cards, no icons. "Onde expandir" + description. "Como projetar" + description. "Quanto investir" + description. Each: text-md semibold title + text-sm secondary description (2 lines max).

Section 3 — Social proof: Grayscale logos in a row (Trópico, Abrint, CPqD if real). No "Trusted by" headline. If no logos yet, skip entirely. Do NOT fake it.

Section 4 — CTA: Centered text "Comece agora — plano gratuito disponível" + one button "Criar conta" → /cadastro. No decorative background.

Section 5 — Footer: 3-column. Logo + description | Page links | Legal links. Bottom: "© 2026 Pulso Network".

## PRODUCT (/produto)

Show what the platform does with REAL screenshots. Each section: text left + screenshot right (alternating). No tabs. No demos. No animations.

Sections: Planejamento de Expansão (opportunity heat map screenshot). Projeto de Cobertura RF (coverage footprint screenshot). Análise Financeira (projection panel screenshot). Conformidade Regulatória (compliance dashboard screenshot). Conectividade Rural (rural hybrid design screenshot). Inteligência de M&A (brief mention, link to /solucoes/mna).

Each: 2-3 short paragraphs of explanation. No bullet lists with icons. Screenshots sell. Text explains what you see.

## SOLUTIONS — ISPs (/solucoes/provedores)

Speak directly to Carlos and Fernanda. Opening: "Você tem 4.000 assinantes e precisa decidir onde expandir. Hoje você faz isso dirigindo pelo bairro. Com Pulso, você vê o mapa de oportunidades antes de sair do escritório."

4 use cases with screenshots: Encontrar o próximo bairro. Saber quem são seus concorrentes. Gerar relatório para o banco. Preparar-se para a Norma nº 4. Each: headline + 2-3 sentences + screenshot. End: pricing link + sign up CTA. NO fake testimonials. NO case studies unless real.

## SOLUTIONS — Private Networks (/solucoes/redes-privativas)

Speak to Marcos and Ricardo. Opening: "Sua fazenda precisa de conectividade para 200 máquinas. Quantas torres? Onde? Quanto custa? Pulso responde em 30 minutos."

4 use cases: Projetar cobertura 4G para agronegócio. Dimensionar sistema solar off-grid. Gerar proposta comercial em menos de 1 hora. Comparar frequências 250/700/3500 MHz. Mention Trópico partnership if applicable.

## SOLUTIONS — M&A (/solucoes/mna)

Speak to Patricia and PE funds. Opening: "O mercado brasileiro de telecom tem mais de 10.000 provedores. Qual deles vale a pena comprar? Por quanto?"

4 use cases: Identificar alvos por estado/tamanho/tecnologia. Estimar valuation com dados da Anatel. Analisar sobreposição com portfólio. Monitorar alertas de mercado. SEPARATE product. Different pricing. Make that clear.

## PRICING (/precos)

Simple table. NOT cards with shadows.

| Plano | Preço/mês | Inclui |
|---|---|---|
| Gratuito | R$ 0 | Mapa de oportunidades (1 estado) |
| Provedor | R$ 1.500 | Expansão + Concorrência + Conformidade + Relatórios |
| Profissional | R$ 5.000 | Tudo acima + Projeto RF + Rotas de Fibra |
| Empresa | Sob consulta | Intel. competitiva completa + API + Customização |

Below: "Dados atualizados mensalmente. Cancele a qualquer momento." FAQ: 4-5 plain text questions and answers. No accordions. M&A pricing: separate section or link. NO "Most Popular" badges. NO annual discount tricks. NO checkmark feature comparisons.

## ABOUT (/sobre)

The story of Brazilian telecom — Telebrás to 10,000 ISPs. The gap. The solution. If Raul is public: his story IS the story. "Do pulso telefônico ao pulso digital." Team grid: names, titles, short bios. No bad headshots (better none than bad). No mission statements. No values sections. No corporate speak. Just the story, told straight.

## CONTACT (/contato)

Form: Nome, Email, Empresa, Mensagem. Plus WhatsApp number. Plus email address. No chatbot. No AI assistant. No calendar widget.

## SIGN UP (/cadastro)

Form: Nome completo, Email, Empresa, Estado (27 UF dropdown), Assinantes (dropdown: <1.000 | 1.000-5.000 | 5.000-20.000 | >20.000), Senha. "Criar conta" button. After: redirect to app.pulso.network. No email verification blocking access. No onboarding wizard. Drop them on the map.

## SITE DESIGN RULES

Max width: 1140px. Section spacing: 80px major, 40px sub. No parallax. No scroll animations. No sticky except nav. No video. No popups. No cookie banners (Plausible). Images: real screenshots only, 1px border, 6px radius. Mobile: hamburger nav, stacked hero, horizontal scroll pricing, readable at 320px.

## PERFORMANCE

Lighthouse >95. FCP <1.0s. LCP <2.0s. Total <500kb excluding screenshots. Font loaded locally. WebP images. No JS for animations.
