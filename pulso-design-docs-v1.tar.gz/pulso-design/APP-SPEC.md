# PULSO APP — Platform Dashboard Specification
## The working tool at app.pulso.network
### Read UNCODIXFY-PULSO.md before building any screen.

## PURPOSE
Where paying customers do real work. Map-first. Every interaction starts and returns to the map.

## TECH STACK
Next.js 14. Deck.gl + Mapbox GL JS. React context + SWR. Tailwind CSS with UNCODIXFY-PULSO tokens. IBM Plex Sans + IBM Plex Mono. Recharts. PDF via WeasyPrint server-side. JWT auth. API: api.pulso.network (FastAPI). pt-BR only, i18n ready.

## APP ROUTES
/ (map dashboard), /expansao, /projeto, /concorrencia, /conformidade, /saude, /rural, /relatorios, /configuracoes, /mna (redirect to mna.pulso.network).

## LAYOUT
No top header. Sidebar 240px left + Map remaining width 100vh + Side Panel 380px right (on click, overlays map). Mobile: sidebar becomes bottom tab bar, map fullscreen, panel slides up from bottom 70% height.

## SIDEBAR (240px fixed)
bg-subtle. 1px border-right. Top: small logo 48px area. Nav items: Mapa, Expansão, Projeto RF, Concorrência, Conformidade, Saúde, Rural, Relatórios. Each 40px height, 16px monochrome icon + text-sm weight 500. Active: accent-subtle bg, accent text, 2px left accent border. Hover: bg-surface. Divider. Bottom: user name text-sm, plan text-xs text-muted, settings icon. Theme toggle icon bottom-most. No badges. No decorations.

## MAP (default view)
Centered on user's state. Opportunity heatmap ON by default. Controls top-right: zoom +/-, layer dropdown, fullscreen. Search top-center: "Buscar município..." 320px input with autocomplete. Attribution bottom-left text-xs. On municipality click: side panel slides in 150ms. Map NEVER in a card, NEVER rounded, edge-to-edge.

## SIDE PANEL (380px)
Slides from right. bg-surface. 1px border-left. Shadow 0 2px 8px. Close X top-right. Content scrollable. Title: municipality name text-md semibold + score number. Subtitle: state, population text-sm text-secondary. Divider. Content sections with key-value pairs (label left text-secondary, value right text-primary tabular-nums). Section headers text-sm weight 600. Sticky action buttons bottom. Score display: just the number with color (80+: accent, 60-79: primary, 40-59: warning, 0-39: danger). No gauges. No donuts. No progress bars.

## EXPANSION (/expansao)
Map + heatmap at higher granularity. Filter bar above map: state dropdown, min score slider, competition filter. 48px bg-subtle. Panel on click: full opportunity analysis, subscriber projection line chart (3 bands), financial key-values (CAPEX, payback, IRR). Buttons: "Gerar Rota de Fibra" and "Exportar Relatório". Route appears as accent polyline 3px on map.

## RF DESIGN (/projeto)
Map with drawing tools. Toolbar 48px bg-subtle: "Desenhar Área" button, frequency dropdown (250/700/3500 MHz/custom), preset dropdown (Agronegócio/Mineração/Ferrovia/Utilidade/custom), "Calcular Cobertura" primary button (disabled until area drawn). Flow: draw polygon → select params → calculate → progress bar top of map → result: tower markers + coverage overlay + panel with tower list, coverage %, BOM table, CAPEX, backhaul. Custom params in panel form: TX power, antenna gain, tower height, min signal, vegetation correction checkbox. All labels Portuguese, defaults pre-filled.

## COMPETITIVE (/concorrencia)
Map colored by HHI or provider presence. Layer options: market concentration heatmap, per-provider highlight, ERB markers filterable. Panel on click: provider table (name, subscribers, share, technology, 3m growth), HHI index, threat alerts, market trend.

## COMPLIANCE (/conformidade)
Panel-focused view. Map 50% + panel 50%. Panel sections: Norma nº 4 (countdown text, tax impact R$, readiness score, restructuring options list). Licenciamento (subscriber count vs 5,000 threshold as text "4.200 / 5.000", estimated timeline). Qualidade (metrics table: metric, your value, threshold, status as text color). Alertas (date + description list, no fancy cards).

## HEALTH (/saude)
Map with weather risk and quality overlays. Panel on click: 7-day weather risk (simple list), quality vs peers (key-values), maintenance priority score, recommended actions (text list).

## RURAL (/rural)
Map with satellite imagery toggle. Toolbar: community type dropdown, "Projeto Híbrido" button. Step wizard in panel: mark location → enter population/area → grid power yes/no → connectivity needs → calculate. Result: technology summary, coverage on map, solar sizing, CAPEX + OPEX, funding eligibility, "Gerar Estudo de Viabilidade" PDF button.

## REPORTS (/relatorios)
Table: date, type, area, status, download link. "Novo Relatório" button: type dropdown, area selection, generate. Server-side PDF, user downloads. No builder wizards.

## SETTINGS (/configuracoes)
No map. Form sections: Perfil (name, email, company, state), Assinatura (plan, usage, upgrade), Equipe (invite by email, member list), Preferências (default state, dark mode), API (key display for Enterprise). Save button per section. "Salvo com sucesso" confirmation text. No auto-save. No toasts.

## MOBILE
Bottom tab bar (Mapa, Expansão, Projeto, Mais). Map fullscreen. Panel slides up 70%. Filter bar collapsible. Drawing simplified. Tables scroll horizontal. Reports download only. Map must load fast and show colors clearly at any zoom. Carlos checks on his phone driving between cities.

## LOADING
Map data: 2px accent progress bar top of map, animated, disappears when loaded. Panel: opens immediately, data fills in 1-2s, no spinner, no skeleton. RF computation: progress bar + "Calculando cobertura... isso pode levar alguns minutos." Reports: button becomes "Gerando..." disabled. NEVER full-screen overlays. NEVER spinners. NEVER skeleton screens.

## ERRORS
API: red banner top of panel "Não foi possível carregar os dados. Tente novamente." No data: "Dados não disponíveis para esta área." Computation failed: specific reason + suggestion. Session expired: redirect to login. NEVER generic messages. NEVER error codes. NEVER stack traces.

## ACCESSIBILITY
Keyboard accessible. Focus ring on all focusable elements. Map: arrows pan, +/- zoom, Enter selects. ARIA labels on icon-only buttons. WCAG AA contrast (4.5:1 normal, 3:1 large). Screen reader: panel announced, tables marked up.
