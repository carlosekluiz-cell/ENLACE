# UNCODIXFY-PULSO
## Design Philosophy & Rules for Pulso Network
### Every interface — site, app, reports, emails — follows these rules.

Based on the Uncodixfy methodology by cyxzdev.
Extended with Pulso-specific telecom platform rules.

---

## CORE PHILOSOPHY

Pulso is a tool for telecom engineers and ISP owners who have been using ugly, functional software their entire careers. They trust tools that look like tools. They distrust anything that looks like it's trying to impress them. The moment the interface feels like a startup pitch deck, you've lost them.

Build like Linear. Build like GitHub. Build like Stripe's dashboard.
Do NOT build like Dribbble. Do NOT build like an AI demo.

The map is the product. Everything else is quiet chrome around the map.

---

## COLOR SYSTEM

### Reserved Colors (NEVER use in UI chrome)

These colors have DATA MEANING on the map. They are sacred. Using them in buttons, borders, badges, or backgrounds creates confusion.

```
Map Opportunity Scale (reserved):
  #1a9641  Dark green   — Score 80-100 (excellent opportunity)
  #a6d96a  Light green  — Score 60-79 (good)
  #ffffbf  Yellow       — Score 40-59 (moderate)
  #fdae61  Orange       — Score 20-39 (poor)
  #d7191c  Red          — Score 0-19 (avoid)

Map Coverage Scale (reserved):
  #006837  Dark green   — Signal > -70 dBm (excellent)
  #31a354  Medium green — -70 to -80 dBm (good)
  #f0e442  Yellow       — -80 to -90 dBm (fair)
  #fd8d3c  Orange       — -90 to -95 dBm (marginal)
  #bd0026  Red          — -95 to -100 dBm (poor)
  transparent           — Below -100 dBm (no coverage)
```

### Pulso Light Mode (DEFAULT)

```
--bg-primary:     #f9fafb
--bg-surface:     #ffffff
--bg-subtle:      #f1f5f9
--text-primary:   #0f172a
--text-secondary: #475569
--text-muted:     #94a3b8
--accent:         #0f766e
--accent-hover:   #0d9488
--accent-subtle:  #f0fdfa
--border:         #e2e8f0
--border-strong:  #cbd5e1
--danger:         #dc2626
--warning:        #d97706
--success:        #059669
```

### Pulso Dark Mode (OPTION)

```
--bg-primary:     #0f0f0f
--bg-surface:     #1a1a1a
--bg-subtle:      #262626
--text-primary:   #f5f5f5
--text-secondary: #a3a3a3
--text-muted:     #737373
--accent:         #2dd4bf
--accent-hover:   #5eead4
--accent-subtle:  #1a2e2b
--border:         #2a2a2a
--border-strong:  #404040
--danger:         #ef4444
--warning:        #f59e0b
--success:        #10b981
```

### Why Teal

Teal is the Pulso signature color because it is distinct from map greens and reds, it is not the overused blue of every SaaS product, it references telecom instrumentation aesthetics, it works in both light and dark modes, and it renders well on low-quality screens that ISP owners in the interior use.

---

## TYPOGRAPHY

### Font: IBM Plex Sans

```
font-family: 'IBM Plex Sans', -apple-system, BlinkMacSystemFont, sans-serif;
```

Why: Excellent Portuguese diacritics at all sizes. Professional engineering feel. Open source. Good number rendering. Distinct from Inter/Roboto. Has monospace variant for data tables.

### Scale

```
--text-xs:    12px    Metadata, timestamps
--text-sm:    13px    Table cells, secondary labels
--text-base:  14px    Body text (NOT 16px — engineers prefer density)
--text-md:    16px    Panel titles, important labels
--text-lg:    18px    Section headers
--text-xl:    22px    Page titles (rare in app)
--text-2xl:   28px    Site headlines only (never in app)

Line heights:  Body 1.5 | Headings 1.25 | Table cells 1.4 | Dense data 1.3
Weights:       400 body | 500 labels/headers | 600 panel titles | 700 site headlines only
```

### Numbers

```
font-variant-numeric: tabular-nums;

Currency: R$ 1.250.000,00 (period thousands, comma decimal)
Percentages: 67,3% (one decimal max)
Subscribers: 4.200 assinantes (period thousands)
Distances: 8,5 km (comma decimal)
Signal: -95 dBm (no comma)
```

---

## SPACING

```
--space-1: 4px | --space-2: 8px | --space-3: 12px | --space-4: 16px
--space-5: 20px | --space-6: 24px | --space-8: 32px | --space-10: 40px

Page margins: 24px | Panel/card padding: 16px | Table cell: 8px 12px
Button: 8px 16px | Input: 8px 12px | Sidebar item: 8px 12px
```

No random spacing. Every value from this scale. No exceptions.

---

## BORDERS AND SHADOWS

```
Borders:  1px solid var(--border) always. Never 2px+. Never gradient. Never colored except focus.
Shadows:  None by default. Subtle (0 1px 3px rgba(0,0,0,0.08)) for dropdowns. Medium (0 2px 8px rgba(0,0,0,0.1)) for modals only. Never dramatic. Never colored.
Radius:   4px inputs/badges | 6px buttons/cards/panels | 8px modals | NEVER 12px+ | NEVER pill (9999px)
```

---

## COMPONENT RULES

### Sidebar (App — 240px)
240px fixed. var(--bg-subtle) background. 1px border-right. Small logo top-left. Navigation as text + optional 16px icon. Active: accent-subtle bg + accent text. No badges unless functional. No decorative elements. No rounded outer corners. No floating appearance.

### Map Container (App — primary element)
Remaining width after sidebar. Full height. No border. No radius. No shadow. Edge-to-edge. Map controls top-right inside map. Search bar top-center. The map is NEVER in a card. NEVER in a rounded container.

### Side Panel (App — appears on click)
380px desktop, 100% mobile. Slides from right over map. var(--bg-surface) bg. 1px border-left. Shadow 0 2px 8px. Close X top-right. Scrollable content. 150ms ease translateX — the ONLY animation in the app. Title + subtitle + divider + content sections + sticky action buttons at bottom.

### Tables
Primary data display. Header: bg-subtle, text-sm, weight 500. Body: bg-surface. Hover: bg-subtle on row. Borders: bottom only per row. Cell padding: 8px 12px. Text left, numbers right. Tabular nums for number columns. IBM Plex Mono for dense data. No zebra. No colored badges in every row. No action buttons in every row unless necessary.

### Buttons
Primary: accent bg, white text, 6px radius, 36px height. Secondary: transparent, 1px border. Danger: for destructive only. Ghost: no bg no border. No gradients. No pills. No icon-only without tooltip. Max 2 side by side. Primary on right.

### Inputs
36px height. 1px border. 4px radius. 8px 12px padding. Focus: accent border + accent-subtle ring. Label above, text-sm weight 500. No floating labels. No animated underlines.

### Charts
Only purposeful charts. Line chart for projections. Horizontal bar for market share. Line for trends. Grouped bar for financials. No donuts ever. No 3D. No animated drawing. No decorative filler charts. Transparent bg. Subtle horizontal grid lines. 2-3 data colors max.

---

## MAP-SPECIFIC RULES

### Layer Controls
Simple checkbox list dropdown. Layers: Oportunidades (on by default), Concorrentes (off), ERBs (off), Rotas (when generated), Cobertura RF (when computed). No icons. No color swatches. Instant toggle. Loading: thin progress bar at top, never spinner.

### Map Popups (hover)
White tooltip, no arrow, subtle shadow. 2-3 lines max. Municipality name (semibold) + key metric + competition status. text-xs. Max 280px width. No animation. Click opens side panel.

### Coverage Footprint
Semi-transparent colors (0.5-0.7 opacity). Clean edges. Legend bottom-right (small, 4-5 swatches). Tower markers: 8px circle, dark gray, 1px white border. No antenna icons. No pulsing.

---

## LANGUAGE RULES (Portuguese)

All UI in Brazilian Portuguese. No English anywhere.

Tone: Direct, professional, no marketing fluff.
- Good: "3.200 domicílios sem fibra nesta área"
- Bad: "Descubra oportunidades incríveis de expansão!"

Error messages: Clear, helpful, never blame user.
Empty states: Tell user what to do, not that something is empty.
- Good: "Clique no mapa para selecionar uma área de análise"
- Bad: "Nenhum dado encontrado"

---

## HARD NO — EVERYTHING BANNED

### From Uncodixfy Core
No oversized rounded corners. No pill overload. No floating glassmorphism. No soft corporate gradients. No generic dark SaaS composition. No decorative sidebar blobs. No control room cosplay. No serif+sans combo. No metric-card grid as first instinct. No fake charts. No random glows/blur/frosted panels. No hero sections inside apps. No dead-space alignment. No overpadded layouts. No ornamental labels. No generic startup copy. No eyebrow labels. No decorative copy. No transform animations on hover. No dramatic shadows. No pipeline bars with gradients. No KPI cards as default. No workspace blocks in sidebar. No nav badges unless functional. No quota panels with progress bars. No footer meta lines. No trend indicators with colored text. No right-side rail panels. No multiple nested panel types.

### Pulso-Specific Additions
No NASA control room aesthetic. No map in a card with rounded corners. No dashboard metrics above the map. No loading spinners on the map. No colored sidebar icons. No decorative map markers (animated/bouncing/pulsing). No full-screen modals hiding the map. No onboarding tooltip tours. No chat widgets or AI assistant bubbles. No "Powered by AI" labels anywhere. No English mixed with Portuguese. No gradient text. No blur/frosted backgrounds. No hero sections in the app. No welcome messages with user's name in big text. No empty state illustrations. No animated page transitions. No skeleton loading screens.

---

## THE TEST

Before any screen goes to production:

1. Would Carlos (42, ISP owner, non-technical) figure out what to do in 5 seconds?
2. Would Raul (80, RF engineer) trust the numbers he sees?
3. Would Fernanda (34, network engineer) find this faster than her manual process?
4. Does the map dominate the screen?
5. Is every color either neutral chrome OR meaningful data?
6. Could this screen be printed in black and white and still be usable?
7. Does it look like Linear/GitHub? Or does it look like a Dribbble shot?

If any answer is wrong, redesign.
