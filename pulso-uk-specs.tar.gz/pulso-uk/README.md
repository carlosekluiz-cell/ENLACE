# PULSO UK — uk.pulso.network

Intelligence + Fibre Planning + Optical Propagation for UK FTTP Operators

## Target Customer: Community Fibre (and all UK altnets)

## Architecture
Same stack as PULSO Brazil: Rust engine + PostGIS + FastAPI + Next.js/Deck.gl + Agente

## Build Sequence (for Claude Code)

1. Read CLAUDE_CODE_PROMPT.md first
2. Phase 1: Data Foundation (Ofcom + OS + ONS ingestion)
3. Phase 2: Intelligence Layer (expansion scoring, competitor mapping, demand forecast)
4. Phase 3: Fibre Route Planner with Optical Budget
5. Phase 4: Build Cost Estimator
6. Phase 5: UI/Dashboard (Deck.gl maps)

## Country Configuration
- Domain: uk.pulso.network
- Language: English
- Currency: GBP
- Regulator: Ofcom
- Geographic unit: Postcode (avg 15 addresses)
- Address ID: UPRN (Unique Property Reference Number)
- Terrain: OS Terrain 50 (free) or SRTM (global)
- Infrastructure: Openreach PIA (ducts/poles via API)
- Census: ONS 2021 Output Areas
