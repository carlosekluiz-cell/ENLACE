# Phase 4: UK-Specific RF Propagation Corrections

## For 5G FWA and Mobile Coverage Planning

### UK Terrain Corrections (extend existing Rust propagation crate)

The existing motor handles 3GPP TR 38.901 models (UMa, UMi, RMa, InF).
For UK, add these terrain and building corrections:

### UK Building Penetration Loss (Building Entry Loss — BEL)

Ofcom uses 10dB average BEL for indoor coverage assessment.
We use building-type-specific values from EPC data:

| Building Type | Age Band | Wall Type | BEL at 800MHz | BEL at 1800MHz | BEL at 3500MHz | BEL at 26GHz |
|--------------|----------|-----------|---------------|----------------|----------------|--------------|
| Victorian terrace | pre-1919 | Solid brick 225mm+ | 12 dB | 16 dB | 20 dB | 35 dB |
| Edwardian semi | 1900-1929 | Solid brick | 11 dB | 15 dB | 18 dB | 32 dB |
| Inter-war semi | 1930-1949 | Cavity brick | 10 dB | 13 dB | 16 dB | 28 dB |
| Post-war council | 1950-1966 | Concrete/brick | 12 dB | 16 dB | 22 dB | 38 dB |
| 1970s-80s build | 1967-1989 | Cavity + insulation | 8 dB | 11 dB | 14 dB | 25 dB |
| Modern detached | 1990-2012 | Timber frame / lightweight | 7 dB | 9 dB | 12 dB | 22 dB |
| New build | 2013+ | High insulation, triple glazing | 9 dB | 12 dB | 15 dB | 28 dB |
| Purpose-built flat (low-rise) | Various | Brick/concrete | 10 dB | 14 dB | 18 dB | 30 dB |
| Tower block (high-rise) | 1960s-70s | Reinforced concrete | 15 dB | 20 dB | 25 dB | 40 dB |
| Modern apartment | 2000+ | Steel frame + cladding | 12 dB | 15 dB | 19 dB | 32 dB |

EPC data gives construction_age_band and built_form per address.
Map postcode → dominant building type → appropriate BEL.

### UK Terrain Morphology Corrections

| Terrain Type | Regions | Correction at 3.5GHz | Notes |
|-------------|---------|---------------------|-------|
| Dense urban (CBD) | City of London, Canary Wharf | Use UMi NLOS, +3dB clutter | Canyon effect between tall buildings |
| Urban residential | Inner London boroughs | Use UMa NLOS, standard | Typical 3-4 storey terraced streets |
| Suburban | Outer London, commuter belt | Use UMa, -2dB less clutter | Lower building density, more open |
| Rural village | Counties | Use RMa LOS/NLOS | Low clutter, good propagation |
| Welsh valleys | South Wales valleys | Use RMa + 8dB valley loss | Steep valley sides block signal from hilltop sites |
| Scottish Highland | Highlands, Islands | Use RMa, excellent propagation but sparse | Few obstructions, very long range possible |
| Coastal | All UK coasts | Use RMa with maritime correction | Lower refractivity near sea, slight ducting |
| Rolling hills | Cotswolds, South Downs, Chilterns | Use RMa + 3dB terrain shadowing | Moderate hills create shadow zones |

### UK Rain Attenuation (ITU-R P.838)

UK average annual rainfall: ~1,100mm
UK rain rate R0.01 (exceeded 0.01% of year): ~22 mm/h (southern England) to ~32 mm/h (western Scotland)

| Frequency | Rain attenuation @22mm/h | Rain attenuation @32mm/h | Impact |
|-----------|------------------------|------------------------|--------|
| 700 MHz | ~0.0 dB/km | ~0.0 dB/km | Negligible |
| 1800 MHz | ~0.0 dB/km | ~0.0 dB/km | Negligible |
| 3500 MHz | ~0.02 dB/km | ~0.04 dB/km | Negligible for urban cells <2km |
| 26 GHz | ~3.5 dB/km | ~6.0 dB/km | Significant — reduces mmWave range 30-50% in heavy rain |

For sub-6GHz (700MHz, 3.5GHz): rain attenuation can be ignored in UK.
For mmWave (26GHz): must include rain margin of 3-6 dB/km in link budget.

### FWA Link Budget for UK

Typical UK FWA deployment: 5G NR 3.5GHz, small cell on rooftop or pole, serving premises within 1-2km.

```
Downlink link budget (3.5GHz, 100MHz BW, 64T64R):
  Base station Tx power: 43 dBm (EIRP with beamforming)
  Beamforming gain: 18 dBi (64T64R)
  Cable/connector loss: -3 dB
  EIRP: 58 dBm

  Path loss (RMa LOS, 1km): 107 dB
  Path loss (UMa NLOS, 1km): 120 dB
  Shadow fading margin: 8 dB
  Building penetration (Victorian terrace @3.5GHz): 20 dB
  Body loss: 0 dB (FWA CPE on windowsill/wall)

  Required SNR (64QAM 3/4, ~400Mbps): 18 dB
  Thermal noise (@100MHz BW): -174 + 80 = -94 dBm
  Noise figure (CPE): 7 dB
  Rx sensitivity: -94 + 7 + 18 = -69 dBm

  Max path loss = 58 - (-69) - 8 - 20 = 99 dB (indoor Victorian terrace)
  Max path loss = 58 - (-69) - 8 - 0 = 119 dB (outdoor CPE)

  Range (indoor Victorian): ~500m (UMa NLOS limited by BEL)
  Range (outdoor CPE): ~1.5km (UMa NLOS)
  Range (rural outdoor): ~3km (RMa, open terrain)
```

This shows why FWA struggles in London's Victorian housing stock — 20dB building loss kills it.
FTTP is always better for London. FWA makes sense only for:
- Rural areas where FTTP is too expensive
- New build estates before FTTP is laid
- Temporary connectivity during FTTP build phase

### Data Source for Building Types

EPC (Energy Performance Certificate) database:
- URL: https://epc.opendatacommunities.org/
- 25+ million records for England and Wales
- Fields: postcode, property_type, built_form, construction_age_band, total_floor_area
- Free download under Open Government Licence
- Use to create building_type_map table: postcode → dominant building type → BEL values
