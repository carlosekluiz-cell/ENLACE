# Phase 1: UK Data Foundation

## Data Sources — Complete URL Reference

### 1. Ofcom Connected Nations (Broadband + Mobile Coverage)
- Main page: https://www.ofcom.org.uk/phones-and-broadband/coverage-and-speeds/connected-nations-2024/data-downloads-2024
- Spring 2025 update: https://www.ofcom.org.uk/phones-and-broadband/coverage-and-speeds/connected-nations-update-spring-2025
- Interactive report: https://www.ofcom.org.uk/phones-and-broadband/coverage-and-speeds/connected-nations-2024/interactive-report-2024
- Methodology annex (PDF): https://www.ofcom.org.uk/siteassets/resources/documents/research-and-data/multi-sector/infrastructure-research/connected-nations-2024/connected-nations-2024-annex.pdf
- England report (PDF): https://www.ofcom.org.uk/siteassets/resources/documents/research-and-data/multi-sector/infrastructure-research/connected-nations-2024/connected-nations-england-report-2024.pdf
- Open data portal: https://www.ofcom.org.uk/research-and-data/data/opendata
- data.gov.uk mirror: https://www.data.gov.uk/dataset/e218662f-2bdb-4e16-b4a8-8c16fdfd52bd/infrastructure-report
- Contains: 116M premises records, 55 operators, per-premises FTTP/FTTC/cable/FWA availability, speeds
- Format: CSV bulk download
- Frequency: Annual (December) + Spring interim update (April/May)
- Key fields: UPRN, postcode, operator, technology, max_download, max_upload, availability

### 2. Ofcom APIs
- Broadband checker: https://checker.ofcom.org.uk/en-gb/broadband-coverage
- API documentation: via api.store (third party gateway) or Ofcom developer portal
- Format: REST API, JSON response
- Query by: postcode
- Returns: broadband availability by technology and speed tier

### 3. OS Code-Point Open (Postcodes)
- Download: https://osdatahub.os.uk/downloads/open (select "Code-Point Open")
- Contains: Every current postcode in Great Britain with Easting/Northing (OSGB36 BNG)
- Format: CSV
- Coordinate system: OSGB36 British National Grid — MUST convert to WGS84 (lat/lon) using EPSG:27700 -> EPSG:4326
- ~1.7 million postcodes, average 15 addresses per postcode
- Fields: Postcode, Easting, Northing, Country_code, NHS_Regional_HA_code, County_code, District_code, Ward_code
- Licence: Open Government Licence (free commercial use with attribution)

### 4. ONS Census 2021 Output Areas
- Boundaries (GeoJSON/Shapefile): https://geoportal.statistics.gov.uk/
  - Search "Output Areas December 2021 Boundaries"
  - ~188,000 output areas in England and Wales, ~46,000 in Scotland
- Population/household data: https://www.nomisweb.co.uk/
  - Census 2021 table TS001 (population) and TS041 (households) by output area
- Postcode to Output Area lookup: https://geoportal.statistics.gov.uk/
  - Search "National Statistics Postcode Lookup" (NSPL)
  - Maps every postcode to OA, LSOA, MSOA, local authority, region, country
- Index of Multiple Deprivation (England): https://www.gov.uk/government/statistics/english-indices-of-deprivation-2019
  - IMD rank and decile per LSOA (Lower Layer Super Output Area)
  - 32,844 LSOAs in England ranked 1 (most deprived) to 32,844
- Locale classification: from Ofcom methodology — groups output areas into Urban/Suburban/Rural
- Format: CSV + GeoJSON/Shapefile
- Licence: Open Government Licence

### 5. OS Terrain 50 (Elevation)
- Download: https://osdatahub.os.uk/downloads/open (select "OS Terrain 50")
- Contains: Contours at 10m intervals, spot heights, for all of Great Britain
- Format: GML or ESRI Shapefile, gridded 50m resolution
- Coordinate system: OSGB36 BNG
- Licence: Open Government Licence (free)
- Alternative: SRTM 30m (global, already used in PULSO Brazil) — works for UK too

### 6. OS Open Roads (Road Network)
- Download: https://osdatahub.os.uk/downloads/open (select "OS Open Roads")
- Contains: Complete road network of Great Britain with road classification
- Format: GML or ESRI Shapefile (LineString geometries)
- Fields: road name, road classification (motorway/A/B/minor/local), one-way, road structure (bridge/tunnel)
- Coordinate system: OSGB36 BNG
- Licence: Open Government Licence (free)

### 7. OS OpenMap Local (Buildings and Land)
- Download: https://osdatahub.os.uk/downloads/open (select "OS OpenMap Local")
- Contains: Building outlines, roads, paths, rail, water, woodland at street level
- Format: GML or ESRI Shapefile
- Licence: Open Government Licence (free)

### 8. OS AddressBase (UPRN — Premium)
- Source: OS Data Hub (premium product, free tier available with API limits)
- Contains: Every addressable location in Great Britain with UPRN
- Fields: UPRN, address, postcode, classification (residential/commercial), coordinates
- ~34 million addressable locations
- Free alternative: OS Open UPRN (https://osdatahub.os.uk/downloads/open) — UPRNs with coordinates but limited attribute data

### 9. Openreach PIA (Duct Infrastructure)
- Portal: https://www.openreach.co.uk — Physical Infrastructure Access
- API: available to registered Communications Providers (CF has access)
- Contains: duct routes (LineString), pole locations (Point), chambers/manholes (Point), capacity status (GREEN/AMBER/RED), sub-duct availability
- Access: requires CP registration and Openreach approval — CF already has this
- Third party tool: Digpro dpCom integrates PIA API for planning
- Key: capacity_status tells you if there's room for more cable in the duct

### 10. EPC Data (Building Types)
- Source: https://epc.opendatacommunities.org/ (England and Wales)
- Contains: Energy Performance Certificate for every property sold/let since 2008
- Fields: address, postcode, property_type (house/flat/maisonette), built_form (detached/semi/terraced/end-terrace), construction_age_band, total_floor_area, current_energy_rating
- Use for: building penetration loss estimation (Victorian terrace vs modern build = different indoor signal loss for FWA)
- Format: CSV download (bulk, ~25 million records)
- Licence: Open Government Licence

### 11. ThinkBroadband API (Aggregated Market Data — Paid)
- Source: https://www.thinkbroadband.com/broadband-availability-api
- Contains per postcode: operator availability (all UK operators), speed estimates, exchange info, speed test data, Ofcom market classification
- Highlights: avail_infra_communityfibre_fttp, avail_infra_openreach_fttp, avail_infra_cityfibre_fttp, avail_infra_virginmedia, etc
- Also: ofcom_market (1/2/3 competitiveness), openreach_postcode_split (single vs multi-cabinet postcodes)
- Format: REST API (JSON)
- Access: Commercial licence (paid per query)
- Alternative: Build same from raw Ofcom data (free but more work)

### 12. Project Gigabit / BDUK (Government Funded Areas)
- Source: https://www.gov.uk/guidance/project-gigabit-uk-gigabit-programme
- Contains: which areas are receiving government subsidy for broadband
- Important: CF should AVOID building in these areas (government already funding, plus subsidy contracts often have exclusivity)
- Format: maps and PDF documents, some open data

## Coordinate System Notes

UK uses OSGB36 British National Grid (EPSG:27700) — Easting/Northing in metres.
PULSO uses WGS84 (EPSG:4326) — latitude/longitude in degrees.

ALL UK data must be transformed from OSGB36 to WGS84 on ingestion.

In Python: use pyproj
```python
from pyproj import Transformer
transformer = Transformer.from_crs("EPSG:27700", "EPSG:4326", always_xy=True)
lon, lat = transformer.transform(easting, northing)
```

In Rust: use proj crate
```rust
use proj::Proj;
let converter = Proj::new_known_crs("EPSG:27700", "EPSG:4326", None).unwrap();
let (lon, lat) = converter.convert((easting, northing)).unwrap();
```

In SQL (PostGIS):
```sql
ST_Transform(ST_SetSRID(ST_MakePoint(easting, northing), 27700), 4326)
```
