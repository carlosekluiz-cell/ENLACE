// pulso-uk-fibre-planner/src/optical/budget.rs
// Optical Power Budget Calculator for GPON/XGS-PON FTTP Networks
// Based on ITU-T G.984 (GPON) and G.9807.1 (XGS-PON)

use serde::{Deserialize, Serialize};

/// PON technology standard
#[derive(Debug, Clone, Serialize, Deserialize)]
pub enum PonStandard {
    /// ITU-T G.984 - 2.488 Gbps down / 1.244 Gbps up
    Gpon,
    /// ITU-T G.9807.1 - 10 Gbps symmetric  
    XgsPon,
    /// ITU-T G.989.2 - 40 Gbps down / 10 Gbps up (4 wavelengths)
    NgPon2,
}

/// OLT transmitter class (determines max output power)
#[derive(Debug, Clone, Serialize, Deserialize)]
pub enum OltClass {
    /// GPON Class B+: +1.5 to +5 dBm, budget 28 dB
    GponBPlus,
    /// GPON Class C+: +3 to +7 dBm, budget 32 dB
    GponCPlus,
    /// XGS-PON N1: +2 to +7 dBm, budget 29 dB
    XgsPonN1,
    /// XGS-PON N2: +2 to +7 dBm, budget 31 dB  
    XgsPonN2,
    /// XGS-PON E1: +3 to +7 dBm, budget 33 dB (extended reach)
    XgsPonE1,
}

impl OltClass {
    pub fn tx_power_max_dbm(&self) -> f64 {
        match self {
            OltClass::GponBPlus => 5.0,
            OltClass::GponCPlus => 7.0,
            OltClass::XgsPonN1 => 7.0,
            OltClass::XgsPonN2 => 7.0,
            OltClass::XgsPonE1 => 7.0,
        }
    }

    pub fn tx_power_min_dbm(&self) -> f64 {
        match self {
            OltClass::GponBPlus => 1.5,
            OltClass::GponCPlus => 3.0,
            OltClass::XgsPonN1 => 2.0,
            OltClass::XgsPonN2 => 2.0,
            OltClass::XgsPonE1 => 3.0,
        }
    }

    pub fn ont_rx_sensitivity_dbm(&self) -> f64 {
        match self {
            OltClass::GponBPlus => -28.0,
            OltClass::GponCPlus => -32.0,
            OltClass::XgsPonN1 => -28.0,
            OltClass::XgsPonN2 => -28.0,
            OltClass::XgsPonE1 => -28.0,
        }
    }

    pub fn max_budget_db(&self) -> f64 {
        match self {
            OltClass::GponBPlus => 28.0,
            OltClass::GponCPlus => 32.0,
            OltClass::XgsPonN1 => 29.0,
            OltClass::XgsPonN2 => 31.0,
            OltClass::XgsPonE1 => 33.0,
        }
    }
}

/// Splitter configuration
#[derive(Debug, Clone, Serialize, Deserialize)]
pub enum SplitterConfig {
    /// Single stage splitter
    Single { ratio: u32 },
    /// Two-stage cascaded splitter
    Cascaded { first_ratio: u32, second_ratio: u32 },
}

impl SplitterConfig {
    /// Total split ratio
    pub fn total_ratio(&self) -> u32 {
        match self {
            SplitterConfig::Single { ratio } => *ratio,
            SplitterConfig::Cascaded { first_ratio, second_ratio } => first_ratio * second_ratio,
        }
    }

    /// Insertion loss in dB for a PLC splitter
    /// Based on typical manufacturer specs (e.g., Corning, AFL)
    pub fn insertion_loss_db(&self) -> f64 {
        match self {
            SplitterConfig::Single { ratio } => Self::splitter_loss(*ratio),
            SplitterConfig::Cascaded { first_ratio, second_ratio } => {
                Self::splitter_loss(*first_ratio) + Self::splitter_loss(*second_ratio)
            }
        }
    }

    fn splitter_loss(ratio: u32) -> f64 {
        match ratio {
            2 => 3.5,
            4 => 7.0,
            8 => 10.5,
            16 => 13.5,
            32 => 17.0,
            64 => 20.0,
            128 => 23.0,
            _ => 10.0 * (ratio as f64).log2() * 0.5 + 3.5 * (ratio as f64).log2(),
        }
    }
}

/// Fibre attenuation coefficients for OS2 singlemode (ITU-T G.652.D)
pub struct FibreAttenuation;

impl FibreAttenuation {
    /// dB/km at 1310nm (GPON upstream, XGS-PON upstream)
    pub const AT_1310NM: f64 = 0.35;
    /// dB/km at 1490nm (GPON downstream)
    pub const AT_1490NM: f64 = 0.25;
    /// dB/km at 1550nm (video overlay / CWDM)
    pub const AT_1550NM: f64 = 0.22;
    /// dB/km at 1577nm (XGS-PON downstream)
    pub const AT_1577NM: f64 = 0.22;

    /// Get worst-case attenuation (use 1310nm as it's highest)
    pub fn worst_case_db_per_km() -> f64 {
        Self::AT_1310NM
    }
}

/// System margins
pub struct SystemMargin;

impl SystemMargin {
    /// Margin for future fibre repairs (splices added during fixes)
    pub const REPAIR_MARGIN_DB: f64 = 1.0;
    /// Margin for fibre aging over 20+ year lifetime
    pub const AGING_MARGIN_DB: f64 = 1.0;
    /// Margin for temperature variation (-40C to +70C)
    pub const TEMPERATURE_MARGIN_DB: f64 = 0.5;
    /// Safety margin
    pub const SAFETY_MARGIN_DB: f64 = 0.5;

    pub fn total_db() -> f64 {
        Self::REPAIR_MARGIN_DB + Self::AGING_MARGIN_DB + Self::TEMPERATURE_MARGIN_DB + Self::SAFETY_MARGIN_DB
    }
}

/// Input parameters for budget calculation
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct BudgetInput {
    pub olt_class: OltClass,
    pub olt_tx_power_dbm: f64,
    pub distance_km: f64,
    pub splice_count: u32,
    pub splice_loss_db_each: f64, // typical 0.05-0.1 for fusion, 0.2-0.5 for mechanical
    pub splitter: SplitterConfig,
    pub connector_pairs: u32, // typically 2-4 (OLT, ODF, splitter, ONT)
    pub connector_loss_db_each: f64, // typical 0.3-0.5 for SC/APC
    pub additional_loss_db: f64, // bends, macro-bends, etc
}

impl Default for BudgetInput {
    fn default() -> Self {
        Self {
            olt_class: OltClass::XgsPonN1,
            olt_tx_power_dbm: 5.0,
            distance_km: 2.0,
            splice_count: 6,
            splice_loss_db_each: 0.1,
            splitter: SplitterConfig::Single { ratio: 32 },
            connector_pairs: 3,
            connector_loss_db_each: 0.5,
            additional_loss_db: 0.0,
        }
    }
}

/// Result of budget calculation
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct BudgetResult {
    pub input: BudgetInput,
    // Individual loss components
    pub fibre_loss_db: f64,
    pub splice_loss_db: f64,
    pub splitter_loss_db: f64,
    pub connector_loss_db: f64,
    pub margin_db: f64,
    pub additional_loss_db: f64,
    // Totals
    pub total_loss_db: f64,
    pub ont_rx_power_dbm: f64,
    pub ont_rx_sensitivity_dbm: f64,
    // Verdict
    pub budget_ok: bool,
    pub remaining_margin_db: f64, // positive = good, negative = fail
    pub max_additional_distance_km: f64, // how much further could the fibre go
    // Split ratio
    pub total_split_ratio: u32,
    pub max_ont_per_pon_port: u32,
}

/// Calculate optical power budget
pub fn calculate_budget(input: &BudgetInput) -> BudgetResult {
    let fibre_loss_db = input.distance_km * FibreAttenuation::worst_case_db_per_km();
    let splice_loss_db = input.splice_count as f64 * input.splice_loss_db_each;
    let splitter_loss_db = input.splitter.insertion_loss_db();
    let connector_loss_db = input.connector_pairs as f64 * input.connector_loss_db_each;
    let margin_db = SystemMargin::total_db();
    let additional_loss_db = input.additional_loss_db;

    let total_loss_db = fibre_loss_db + splice_loss_db + splitter_loss_db
        + connector_loss_db + margin_db + additional_loss_db;

    let ont_rx_power_dbm = input.olt_tx_power_dbm - total_loss_db;
    let ont_rx_sensitivity_dbm = input.olt_class.ont_rx_sensitivity_dbm();
    let remaining_margin_db = ont_rx_power_dbm - ont_rx_sensitivity_dbm;
    let budget_ok = remaining_margin_db >= 0.0;

    // Calculate max additional distance before budget fails
    let max_additional_loss = if remaining_margin_db > 0.0 { remaining_margin_db } else { 0.0 };
    let max_additional_distance_km = max_additional_loss / FibreAttenuation::worst_case_db_per_km();

    BudgetResult {
        input: input.clone(),
        fibre_loss_db,
        splice_loss_db,
        splitter_loss_db,
        connector_loss_db,
        margin_db,
        additional_loss_db,
        total_loss_db,
        ont_rx_power_dbm,
        ont_rx_sensitivity_dbm,
        budget_ok,
        remaining_margin_db,
        max_additional_distance_km,
        total_split_ratio: input.splitter.total_ratio(),
        max_ont_per_pon_port: input.splitter.total_ratio(),
    }
}

/// Calculate budget for a specific premises on a route
pub fn calculate_premises_budget(
    olt_class: &OltClass,
    olt_tx_power_dbm: f64,
    distance_from_olt_km: f64,
    splice_count_to_premises: u32,
    splitter: &SplitterConfig,
    drop_cable_length_m: f64, // from distribution point to premises
) -> BudgetResult {
    let total_distance_km = distance_from_olt_km + (drop_cable_length_m / 1000.0);
    // Drop cable typically has 1 extra splice + 1 extra connector pair
    let total_splices = splice_count_to_premises + 1;
    let total_connectors = 3; // OLT + splitter + ONT

    let input = BudgetInput {
        olt_class: olt_class.clone(),
        olt_tx_power_dbm,
        distance_km: total_distance_km,
        splice_count: total_splices,
        splice_loss_db_each: 0.1,
        splitter: splitter.clone(),
        connector_pairs: total_connectors,
        connector_loss_db_each: 0.5,
        additional_loss_db: 0.0,
    };

    calculate_budget(&input)
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_typical_cf_scenario() {
        // Community Fibre typical: XGS-PON, 3km urban London, 1:32 split
        let input = BudgetInput {
            olt_class: OltClass::XgsPonN1,
            olt_tx_power_dbm: 5.0,
            distance_km: 3.0,
            splice_count: 8,
            splice_loss_db_each: 0.1,
            splitter: SplitterConfig::Single { ratio: 32 },
            connector_pairs: 3,
            connector_loss_db_each: 0.5,
            additional_loss_db: 0.0,
        };
        let result = calculate_budget(&input);
        
        assert!(result.budget_ok, "3km with 1:32 should pass budget");
        assert!(result.ont_rx_power_dbm > -25.0, "Should have good margin");
        assert!(result.remaining_margin_db > 3.0, "Should have >3dB margin");
    }

    #[test]
    fn test_long_reach_fails() {
        // Edge case: 15km with 1:64 split — should fail
        let input = BudgetInput {
            olt_class: OltClass::XgsPonN1,
            olt_tx_power_dbm: 5.0,
            distance_km: 15.0,
            splice_count: 20,
            splice_loss_db_each: 0.1,
            splitter: SplitterConfig::Single { ratio: 64 },
            connector_pairs: 4,
            connector_loss_db_each: 0.5,
            additional_loss_db: 0.0,
        };
        let result = calculate_budget(&input);
        
        assert!(!result.budget_ok, "15km with 1:64 should fail budget");
    }

    #[test]
    fn test_cascaded_splitter() {
        // Cascaded 1:4 + 1:8 = 1:32 total, slightly more loss than single 1:32
        let input = BudgetInput {
            olt_class: OltClass::XgsPonN1,
            olt_tx_power_dbm: 5.0,
            distance_km: 3.0,
            splice_count: 10, // more splices with cascaded (extra at cabinet)
            splice_loss_db_each: 0.1,
            splitter: SplitterConfig::Cascaded { first_ratio: 4, second_ratio: 8 },
            connector_pairs: 4,
            connector_loss_db_each: 0.5,
            additional_loss_db: 0.0,
        };
        let result = calculate_budget(&input);
        
        assert_eq!(result.total_split_ratio, 32);
        assert!(result.splitter_loss_db > 17.0, "Cascaded should have more loss than single");
        // 7.0 + 10.5 = 17.5 vs 17.0 for single 1:32
        assert!((result.splitter_loss_db - 17.5).abs() < 0.01);
    }

    #[test]
    fn test_gpon_class_b_plus() {
        let input = BudgetInput {
            olt_class: OltClass::GponBPlus,
            olt_tx_power_dbm: 3.0, // mid-range for B+
            distance_km: 5.0,
            splice_count: 10,
            splice_loss_db_each: 0.1,
            splitter: SplitterConfig::Single { ratio: 32 },
            connector_pairs: 3,
            connector_loss_db_each: 0.5,
            additional_loss_db: 0.0,
        };
        let result = calculate_budget(&input);
        
        // 1.75 + 1.0 + 17.0 + 1.5 + 3.0 = 24.25
        // ONT Rx = 3.0 - 24.25 = -21.25
        // Margin = -21.25 - (-28) = 6.75
        assert!(result.budget_ok);
        assert!((result.remaining_margin_db - 6.75).abs() < 0.1);
    }

    #[test]
    fn test_splitter_losses() {
        assert!((SplitterConfig::Single { ratio: 2 }.insertion_loss_db() - 3.5).abs() < 0.01);
        assert!((SplitterConfig::Single { ratio: 4 }.insertion_loss_db() - 7.0).abs() < 0.01);
        assert!((SplitterConfig::Single { ratio: 8 }.insertion_loss_db() - 10.5).abs() < 0.01);
        assert!((SplitterConfig::Single { ratio: 16 }.insertion_loss_db() - 13.5).abs() < 0.01);
        assert!((SplitterConfig::Single { ratio: 32 }.insertion_loss_db() - 17.0).abs() < 0.01);
        assert!((SplitterConfig::Single { ratio: 64 }.insertion_loss_db() - 20.0).abs() < 0.01);
    }
}
