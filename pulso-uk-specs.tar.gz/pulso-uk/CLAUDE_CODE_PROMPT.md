Read this entire prompt before starting.

# PULSO UK — uk.pulso.network
# Intelligence + Fibre Planning + Optical Propagation for UK FTTP Operators
# Claude Code Build Prompt

## CONTEXT

PULSO is a telecom intelligence platform built in Rust + PostGIS + FastAPI + Next.js/Deck.gl.
The Brazil version (br.pulso.network) is already built with Anatel/IBGE/SRTM data.
Now build the UK version (uk.pulso.network) using UK open data sources.
Target customer: Community Fibre (London's largest FTTP altnet, 1.342M premises, 429K customers, £113M revenue).
Same Rust engine architecture. Different data sources. Different schemas.

## PHASE 1: DATA FOUNDATION

### 1.1 Database Schema (PostgreSQL + PostGIS)

Create init_uk.sql with these tables:

```sql
-- UK Postcodes (from OS Code-Point Open)
CREATE TABLE uk_postcodes (
    postcode VARCHAR(8) PRIMARY KEY,
    lat DOUBLE PRECISION NOT NULL,
    lon DOUBLE PRECISION NOT NULL,
    geom GEOMETRY(Point, 4326),
    output_area_code VARCHAR(12),
    local_authority_code VARCHAR(12),
    country VARCHAR(20), -- England, Scotland, Wales, NI
    region VARCHAR(50),
    premises_count INTEGER,
    ofcom_market INTEGER -- 1, 2, or 3 (competitiveness classification)
);
CREATE INDEX idx_postcodes_geom ON uk_postcodes USING GIST(geom);
CREATE INDEX idx_postcodes_oa ON uk_postcodes(output_area_code);

-- Broadband Coverage per Postcode per Operator (from Ofcom Connected Nations)
CREATE TABLE uk_broadband_coverage (
    id SERIAL PRIMARY KEY,
    postcode VARCHAR(8) REFERENCES uk_postcodes(postcode),
    report_date DATE NOT NULL,
    operator VARCHAR(100) NOT NULL,
    technology VARCHAR(20) NOT NULL, -- FTTP, FTTC, Cable, FWA, ADSL
    max_download_mbps REAL,
    max_upload_mbps REAL,
    availability VARCHAR(20), -- AVAILABLE, NOT_AVAILABLE, PARTIAL
    premises_with_service INTEGER,
    premises_total INTEGER,
    UNIQUE(postcode, report_date, operator, technology)
);
CREATE INDEX idx_coverage_postcode ON uk_broadband_coverage(postcode);
CREATE INDEX idx_coverage_operator ON uk_broadband_coverage(operator);
CREATE INDEX idx_coverage_tech ON uk_broadband_coverage(technology);

-- Mobile Coverage per Postcode per Operator (from Ofcom)
CREATE TABLE uk_mobile_coverage (
    id SERIAL PRIMARY KEY,
    postcode VARCHAR(8) REFERENCES uk_postcodes(postcode),
    report_date DATE NOT NULL,
    operator VARCHAR(50) NOT NULL, -- Three, Vodafone, EE, VMO2
    technology VARCHAR(10) NOT NULL, -- 2G, 3G, 4G, 5G
    outdoor_coverage BOOLEAN,
    indoor_coverage BOOLEAN,
    signal_strength_dbm REAL,
    UNIQUE(postcode, report_date, operator, technology)
);

-- Census Output Areas (from ONS 2021)
CREATE TABLE uk_output_areas (
    oa_code VARCHAR(12) PRIMARY KEY,
    lsoa_code VARCHAR(12),
    msoa_code VARCHAR(12),
    local_authority_code VARCHAR(12),
    local_authority_name VARCHAR(100),
    region VARCHAR(50),
    country VARCHAR(20),
    population INTEGER,
    households INTEGER,
    area_hectares REAL,
    density_per_hectare REAL,
    geom GEOMETRY(MultiPolygon, 4326),
    -- Deprivation
    imd_rank INTEGER,
    imd_decile INTEGER, -- 1=most deprived, 10=least
    -- Locale classification
    locale_group VARCHAR(30), -- Urban, Suburban, Rural etc
    is_urban BOOLEAN
);
CREATE INDEX idx_oa_geom ON uk_output_areas USING GIST(geom);

-- Operators Registry
CREATE TABLE uk_operators (
    id SERIAL PRIMARY KEY,
    name VARCHAR(100) NOT NULL UNIQUE,
    type VARCHAR(30), -- altnet, incumbent, cable, mobile, fwa
    premises_passed INTEGER,
    customers INTEGER,
    revenue_gbp BIGINT,
    website VARCHAR(200),
    has_fttp BOOLEAN DEFAULT FALSE,
    has_fttc BOOLEAN DEFAULT FALSE,
    has_cable BOOLEAN DEFAULT FALSE,
    has_fwa BOOLEAN DEFAULT FALSE,
    has_mobile BOOLEAN DEFAULT FALSE,
    notes TEXT
);

-- Expansion Opportunities (computed)
CREATE TABLE uk_expansion_scores (
    id SERIAL PRIMARY KEY,
    postcode VARCHAR(8) REFERENCES uk_postcodes(postcode),
    computed_date DATE NOT NULL,
    target_operator VARCHAR(100), -- which operator is this score for
    premises_count INTEGER,
    competitors_fttp INTEGER, -- how many FTTP operators already present
    competitors_list TEXT, -- comma-separated names
    has_decent_broadband BOOLEAN, -- >=10Mbps available
    has_superfast BOOLEAN, -- >=30Mbps
    has_ultrafast BOOLEAN, -- >=300Mbps
    has_gigabit BOOLEAN,
    demand_score REAL, -- 0-100 based on density + deprivation + no-fttp
    competition_score REAL, -- 0-100, lower = less competition = better
    distance_to_nearest_pop_m REAL,
    estimated_capex_per_premises REAL,
    estimated_take_up_pct REAL,
    estimated_payback_years REAL,
    overall_score REAL, -- composite ranking
    UNIQUE(postcode, computed_date, target_operator)
);
CREATE INDEX idx_expansion_score ON uk_expansion_scores(overall_score DESC);

-- Fibre Routes (planned/existing)
CREATE TABLE uk_fibre_routes (
    id SERIAL PRIMARY KEY,
    route_name VARCHAR(200),
    operator VARCHAR(100),
    from_pop VARCHAR(100),
    to_area VARCHAR(200),
    route_geom GEOMETRY(LineString, 4326),
    total_length_m REAL,
    duct_length_m REAL, -- in existing ducts
    new_build_length_m REAL, -- new duct required
    fibre_type VARCHAR(20), -- OS2 singlemode
    total_splices INTEGER,
    total_splitters INTEGER,
    splitter_config VARCHAR(20), -- 1:32, 1:64, cascaded
    optical_budget_db REAL, -- total loss budget
    olt_tx_power_dbm REAL DEFAULT 5.0,
    min_ont_rx_power_dbm REAL DEFAULT -28.0,
    budget_margin_db REAL, -- positive = OK, negative = FAIL
    premises_served INTEGER,
    estimated_capex_gbp REAL,
    capex_per_premises REAL,
    status VARCHAR(20) DEFAULT 'planned' -- planned, approved, building, live
);
CREATE INDEX idx_routes_geom ON uk_fibre_routes USING GIST(route_geom);

-- Optical Budget Calculations per premises on a route
CREATE TABLE uk_optical_budget (
    id SERIAL PRIMARY KEY,
    route_id INTEGER REFERENCES uk_fibre_routes(id),
    uprn BIGINT, -- Unique Property Reference Number
    postcode VARCHAR(8),
    distance_from_olt_m REAL,
    fibre_loss_db REAL, -- distance * 0.35dB/km
    splice_count INTEGER,
    splice_loss_db REAL, -- count * 0.1dB
    splitter_stages INTEGER, -- 1 or 2 (cascaded)
    splitter_loss_db REAL, -- e.g. 17dB for 1:32
    connector_loss_db REAL, -- typically 0.5dB per connector pair
    total_loss_db REAL,
    ont_rx_power_dbm REAL, -- olt_tx - total_loss
    budget_ok BOOLEAN, -- ont_rx >= -28dBm
    margin_db REAL -- ont_rx - (-28)
);
CREATE INDEX idx_optical_route ON uk_optical_budget(route_id);

-- PIA Duct Network (from Openreach PIA API)
CREATE TABLE uk_pia_ducts (
    id SERIAL PRIMARY KEY,
    pia_asset_id VARCHAR(50) UNIQUE,
    asset_type VARCHAR(30), -- duct, pole, chamber, manhole, cabinet
    geom GEOMETRY(Geometry, 4326), -- LineString for ducts, Point for poles/chambers
    capacity_status VARCHAR(10), -- GREEN, AMBER, RED
    available_subducts INTEGER,
    total_subducts INTEGER,
    duct_size_mm INTEGER,
    road_name VARCHAR(200),
    postcode VARCHAR(8)
);
CREATE INDEX idx_pia_geom ON uk_pia_ducts USING GIST(geom);
CREATE INDEX idx_pia_type ON uk_pia_ducts(asset_type);
CREATE INDEX idx_pia_capacity ON uk_pia_ducts(capacity_status);
```

### 1.2 Data Ingestion Pipelines (Python/Prefect)

Create pipelines for:

**Pipeline 1: Ofcom Connected Nations**
- Source: ofcom.org.uk/phones-and-broadband/coverage-and-speeds/connected-nations-2024/data-downloads-2024
- Download CSV bulk data (broadband coverage per postcode, mobile coverage)
- Parse and load into uk_broadband_coverage and uk_mobile_coverage
- Frequency: Annual (with Spring interim update)
- Data volume: ~116 million premises records across 55 operators

**Pipeline 2: OS Code-Point Open (Postcodes)**
- Source: osdatahub.os.uk/downloads/open — Code-Point Open
- Download CSV of all UK postcodes with Easting/Northing (OSGB36)
- Convert OSGB36 to WGS84 (lat/lon) using pyproj
- Load into uk_postcodes
- Frequency: Twice yearly

**Pipeline 3: ONS Census Output Areas**
- Source: geoportal.statistics.gov.uk — Output Area boundaries (GeoJSON/Shapefile)
- Source: nomisweb.co.uk — Census 2021 population/household data per OA
- Source: gov.uk — Index of Multiple Deprivation
- Load boundaries into uk_output_areas with PostGIS
- Join census data and IMD scores
- Frequency: Decennial census, annual IMD update

**Pipeline 4: OS Terrain 50**
- Source: osdatahub.os.uk/downloads/open — OS Terrain 50
- Download elevation contours for all Great Britain
- Load into PostGIS or process into raster tiles for elevation queries
- Used for: duct depth planning, route gradient analysis
- Frequency: Static (terrain doesn't change)

**Pipeline 5: OS Open Roads**
- Source: osdatahub.os.uk/downloads/open — OS Open Roads
- Complete road network of Great Britain
- Load as LineString geometries into PostGIS
- Used for: fibre route reference, duct route validation
- Frequency: Twice yearly

**Pipeline 6: UK Operators Registry**
- Manual + scraped data on all UK FTTP operators
- Community Fibre, CityFibre, Hyperoptic, Gigaclear, Fibrus, Zzoomm, G.Network, Netomnia, Lit Fibre, Jurassic Fibre, Truespeed, Openreach, Virgin Media O2, etc
- Premises passed, customers, technologies, coverage areas
- Update quarterly from press releases and Ofcom data

**Pipeline 7: Openreach PIA (when CF provides access)**
- Source: Openreach PIA API (requires CP registration — CF has this)
- Download duct routes, pole locations, chamber positions, capacity status
- Load into uk_pia_ducts
- Used for: fibre route planning through existing ducts
- Frequency: On-demand per expansion area

Each pipeline is a Prefect flow with: download -> validate -> transform -> load -> verify row counts.

---

## PHASE 2: INTELLIGENCE LAYER

### 2.1 Expansion Scoring Engine (Rust crate: pulso-uk-intelligence)

```
src/
  lib.rs
  scoring/
    mod.rs
    demand.rs       — demand score per postcode (density, deprivation, growth)
    competition.rs  — competition score (how many FTTP operators present)
    distance.rs     — distance to nearest operator POP
    cost.rs         — estimated CAPEX per premises
    takeup.rs       — predicted take-up based on comparable areas
    composite.rs    — weighted composite score combining all factors
  analysis/
    mod.rs
    whitespace.rs   — find postcodes with zero FTTP (whitespace analysis)
    competitor.rs   — per-operator coverage footprint and overlap
    gaps.rs         — underserved areas (decent broadband but no gigabit)
    overbuild.rs    — areas where multiple altnets already building (avoid)
  ranking/
    mod.rs
    ranker.rs       — rank postcodes by composite score for a target operator
    clustering.rs   — group adjacent high-score postcodes into expansion areas
    phasing.rs      — suggest build phases by priority
```

**Scoring Algorithm:**

For each postcode, compute:

demand_score (0-100):
- premises_count: 0-15 = 10pts, 15-30 = 30pts, 30-50 = 60pts, 50+ = 100pts
- imd_decile: 1-3 (deprived) = +20pts (social tariff opportunity), 4-7 = +10pts, 8-10 = 0pts
- no_gigabit_available: +30pts if no gigabit from any operator
- no_fttp_available: +50pts if no FTTP from any operator
- Normalize to 0-100

competition_score (0-100, lower = better for expansion):
- 0 FTTP operators = 100 (best — no competition)
- 1 FTTP operator = 60
- 2 FTTP operators = 30
- 3+ FTTP operators = 0 (overbuild — avoid)
- If only FTTC/cable available (no FTTP): = 80

distance_score (0-100):
- Within 500m of existing POP: 100
- 500m-1km: 80
- 1-2km: 60
- 2-5km: 40
- 5km+: 20

cost_score (0-100):
- Estimated CAPEX per premises: <£200 = 100, £200-400 = 80, £400-600 = 60, £600-1000 = 40, £1000+ = 20
- CAPEX depends on: duct availability (PIA vs new build), distance, density

takeup_prediction:
- Based on comparable areas: match by IMD decile, locale type, competitor landscape
- CF average take-up: 32%. Adjust up in areas with no FTTP competition, down where overbuild.
- Range: 20-50%

overall_score = (demand * 0.30) + (competition * 0.25) + (distance * 0.20) + (cost * 0.15) + (takeup * 0.10)

**Whitespace Analysis:**
Find all postcodes where:
- premises >= 15
- FTTP operators = 0
- Within 5km of CF's existing network
- Not in Project Gigabit contracted area (government already funding)
These are the prime expansion targets.

**Clustering:**
Group adjacent high-scoring postcodes into expansion areas using DBSCAN spatial clustering (eps=500m, min_samples=5 postcodes). Each cluster becomes a potential expansion project with aggregated premises count, estimated CAPEX, and projected revenue.

### 2.2 Competitor Intelligence

For each postcode, track:
- Which operators offer FTTP (Openreach, CityFibre, Hyperoptic, G.Network, Zzoomm, CF itself, etc)
- Which operators offer FTTC (Openreach, Sky, TalkTalk, etc)
- Which operators offer cable (Virgin Media)
- Which operators offer FWA (Three, Vodafone, Starlink)
- Max available speed from any operator
- Speed gap: difference between max available and gigabit

For each competitor, track:
- Total premises passed
- Expansion trajectory (premises added per quarter from Ofcom data)
- Where they're likely to build next (extrapolate from recent build patterns)

---

## PHASE 3: FIBRE ROUTE PLANNER WITH OPTICAL BUDGET

### 3.1 Rust Crate: pulso-uk-fibre-planner

```
src/
  lib.rs
  routing/
    mod.rs
    dijkstra.rs     — shortest path through duct network
    duct_router.rs  — route through PIA ducts preferring GREEN capacity
    new_build.rs    — route through roads where no ducts exist
    combined.rs     — hybrid routing: ducts where available, new build where not
  optical/
    mod.rs
    budget.rs       — optical power budget calculator
    fibre_loss.rs   — attenuation per km for OS2 singlemode (0.35dB/km @1310nm, 0.25dB/km @1550nm)
    splice_loss.rs  — fusion splice loss model (0.05-0.1dB per splice)
    splitter_loss.rs — splitter insertion loss (1:2=3.5dB, 1:4=7dB, 1:8=10.5dB, 1:16=13.5dB, 1:32=17dB, 1:64=20dB)
    connector_loss.rs — connector pair loss (0.3-0.5dB per pair)
    margin.rs       — system margin calculation (repair margin 1dB, aging 1dB, temperature 0.5dB)
    validator.rs    — validate total budget against OLT tx power and ONT rx sensitivity
  splitter/
    mod.rs
    placer.rs       — optimal splitter placement along duct route
    cascade.rs      — cascaded splitter design (e.g. 1:4 at cabinet + 1:8 at DP = 1:32 total)
    reach.rs        — calculate how many premises each splitter serves
  cost/
    mod.rs
    duct_rental.rs  — PIA duct rental costs (Openreach pricing)
    new_build.rs    — new duct construction costs per metre by road type
    equipment.rs    — OLT line cards, splitters, splice closures, ONTs
    labour.rs       — installation labour costs
    total.rs        — total CAPEX per route, per premises
  report/
    mod.rs
    route_report.rs — GeoJSON of planned route with optical budget per premises
    cost_report.rs  — itemised cost breakdown
    feasibility.rs  — pass/fail feasibility with reasons
```

**Optical Budget Calculation:**

For GPON (G.984):
- OLT Tx power: +1.5 to +5 dBm (Class B+)
- ONT Rx sensitivity: -28 dBm (minimum)
- Max differential loss budget: 28 dB (Class B+)

For XGS-PON (G.9807.1) — what CF uses:
- OLT Tx power: +2 to +7 dBm (N1 class)
- ONT Rx sensitivity: -28 dBm
- Max differential loss budget: 29 dB (N1 class)

Loss calculation per premises:
```
total_loss = fibre_loss + splice_loss + splitter_loss + connector_loss + margin

where:
  fibre_loss = distance_km * 0.35  (dB, at 1310nm for GPON upstream)
  splice_loss = num_splices * 0.1  (dB, fusion splice average)
  splitter_loss = depends on config:
    1:32 single stage = 17.0 dB
    1:4 + 1:8 cascaded = 7.0 + 10.5 = 17.5 dB
    1:64 single stage = 20.0 dB
    1:8 + 1:8 cascaded = 10.5 + 10.5 = 21.0 dB
  connector_loss = num_connectors * 0.5  (dB, SC/APC pair)
    typical: 2 pairs (OLT + ONT) = 1.0 dB
    with patch panels: 3-4 pairs = 1.5-2.0 dB
  margin = 3.0 dB (repair 1.0 + aging 1.0 + temperature 0.5 + safety 0.5)

ont_rx_power = olt_tx_power - total_loss
budget_ok = ont_rx_power >= -28.0

Example:
  OLT Tx: +5 dBm
  Distance: 3km, fibre_loss = 1.05 dB
  Splices: 8, splice_loss = 0.8 dB
  Splitter: 1:32, splitter_loss = 17.0 dB
  Connectors: 3 pairs, connector_loss = 1.5 dB
  Margin: 3.0 dB
  Total loss: 23.35 dB
  ONT Rx: +5 - 23.35 = -18.35 dBm
  Budget OK: YES (margin = 9.65 dB above -28)
```

**Splitter Placement Optimisation:**

Given a duct route from POP to target area:
1. Identify premises along the route and in the target area (from UPRN/postcode data)
2. For each candidate splitter location (chambers, manholes, distribution points along the route):
   - Calculate how many premises it can serve within fibre drop distance (typically <500m)
   - Calculate optical budget for the furthest premises it serves
   - Verify budget is OK for all premises
3. Select splitter locations using greedy set cover:
   - Pick location that serves most premises with valid optical budget
   - Repeat until all target premises are covered
4. Refine with simulated annealing to minimise total splitter count while maintaining coverage

**Splitter Configuration Selection:**
- If premises per POP < 512: use 1:32 splitters (16 PON ports x 32 = 512)
- If premises per POP 512-2048: use 1:64 or cascaded 1:4 + 1:16
- If premises > 2048: need multiple OLTs or larger chassis
- Always verify optical budget — if route is long (>10km), may need lower split ratio

**New Build vs PIA Decision:**
For each segment of the route:
- If PIA duct available with GREEN capacity: use PIA (cheapest)
- If PIA duct available with AMBER capacity: check if sub-duct fits (may need blockage clearance)
- If PIA duct RED (full) or no duct exists: new build required
  - Check road type: footpath (£60-80/m), minor road (£80-120/m), major road (£120-200/m)
  - Check for wayleave requirements
  - Check for traffic management costs

**Cost Model (UK specific):**

PIA duct rental: ~£1.40/metre/year (Openreach regulated price)
PIA pole rental: ~£4.55/pole/year
Sub-duct installation in existing duct: £5-15/metre
Cable blowing in sub-duct: £2-5/metre
New duct construction: £60-200/metre depending on road type
Splice closure: £200-500 each
Fusion splice: £10-20 per splice (labour)
1:32 Splitter (PLC): £100-200 each
OLT PON port (XGS-PON): £500-1000 per port
ONT (customer premises): £50-150 each
Drop cable per premises: £100-300 (depends on distance and method)
Installation labour per premises: £100-200

---

## PHASE 4: 5G / FWA PROPAGATION (for non-fibre areas)

### 4.1 Extend existing pulso-propagation crate for UK

Add UK-specific corrections to the existing Rust propagation engine:

**UK terrain corrections:**
- Rolling hills (South Downs, Cotswolds): standard Okumura-Hata suburban
- Welsh valleys: +5-10dB extra loss for steep valley sides blocking signal
- Scottish Highlands: rural macro with very low clutter, good propagation but sparse population
- Dense urban London: UMi model with high building loss (+15-20dB indoor penetration for Victorian terraced houses with thick brick walls)
- UK weather: rain attenuation for 3.5GHz is negligible (<0.01dB/km), but for 26GHz use ITU-R P.838 with UK rainfall rates (annual avg 1,100mm, hourly peak ~30mm/h)

**UK building penetration:**
- Victorian terrace (brick, 1850-1919): 15-20dB at 3.5GHz
- Semi-detached (cavity wall, 1920-1960): 12-15dB
- Modern build (2000+, lightweight walls, double glazing): 8-12dB
- High-rise flats (concrete): 20-25dB
- Use EPC (Energy Performance Certificate) data to identify building type per postcode

**FWA Use Case:**
Some areas CF can't reach with fibre (too expensive per premises). 5G FWA is the alternative.
Calculate: if CF puts a 5G small cell on an existing pole/rooftop, how many premises can it cover?
Use 3GPP 38.901 RMa for rural, UMa for suburban, UMi for urban.
Output: coverage map overlay on the expansion intelligence map.

---

## PHASE 5: API AND AGENTE

### 5.1 FastAPI endpoints (Python)

```python
# Expansion Intelligence
GET /api/uk/expansion/scores?operator=community_fibre&min_score=70&limit=500
GET /api/uk/expansion/whitespace?max_distance_km=5&min_premises=15
GET /api/uk/expansion/clusters?min_premises=200
GET /api/uk/competitor/coverage?postcode=SW2+3AB
GET /api/uk/competitor/overlap?operator1=community_fibre&operator2=cityfibre

# Fibre Planning
POST /api/uk/fibre/plan-route  (body: {from_pop, to_postcodes, splitter_config})
GET /api/uk/fibre/optical-budget?route_id=123
GET /api/uk/fibre/cost-estimate?route_id=123
POST /api/uk/fibre/validate-budget  (body: {distance_km, splices, splitter_ratio, connectors})

# FWA/5G Coverage
POST /api/uk/propagation/coverage  (body: {lat, lon, frequency_mhz, height_m, power_dbm, technology})
GET /api/uk/propagation/fwa-feasibility?postcode=SW2+3AB

# Market Intelligence
GET /api/uk/market/operator/{operator_name}
GET /api/uk/market/postcode/{postcode}
GET /api/uk/market/stats?local_authority=Lambeth
```

### 5.2 Agente Integration

The PULSO agente (pulso.network/agente) for UK speaks English and understands UK telecom context:
- "Where should Community Fibre expand next in South London?"
- "How many premises in Croydon have no FTTP?"
- "Plan a fibre route from our Lambeth POP to the SW16 postcodes"
- "What's the optical budget if I use 1:32 splitters over 4km?"
- "Show me all postcodes where only Virgin Media cable is available but no FTTP"
- "Estimate build cost for 2000 premises in Bromley"
- "Which areas is CityFibre building in that overlap with our plans?"

Each query hits the Rust engine via API, computes in milliseconds, returns results with map.

---

## DEPENDENCIES

Rust crates:
- geo, geojson (geographic)
- petgraph (graph algorithms for Dijkstra routing)
- rayon (parallel computation)
- serde, serde_json, serde_yaml (serialization)
- tokio (async for API serving)
- sqlx (PostgreSQL async)
- reqwest (HTTP for PIA API, Ofcom downloads)
- proj (coordinate transformations OSGB36 <-> WGS84)
- tracing (logging)

Python:
- prefect (pipeline orchestration)
- fastapi + uvicorn
- sqlalchemy + asyncpg
- geopandas + shapely
- pyproj (OSGB36 to WGS84 conversion)
- pandas

Infrastructure:
- PostgreSQL 16 + PostGIS 3.4
- Redis (caching)
- Docker Compose

---

## TESTS

1. Load OS Code-Point Open for London postcodes. Verify all London postcodes have valid coordinates.
2. Load Ofcom Connected Nations for London. Verify coverage data for CF, Openreach, Virgin Media, CityFibre, Hyperoptic.
3. Run expansion scoring for CF in South London. Top results should be postcodes with high density, no FTTP competition, close to CF POPs.
4. Plan a fibre route from a mock POP in Lambeth to 10 postcodes in SW16. Verify optical budget passes for all premises within 5km with 1:32 splitter.
5. Optical budget edge case: 12km route with cascaded 1:4+1:8 splitters, 15 splices. Should FAIL budget (total loss > 29dB for XGS-PON N1).
6. Cost estimate for 500 premises expansion in Bromley using 80% PIA ducts and 20% new build. Should output itemised CAPEX with per-premises cost.
7. FWA coverage: place 3.5GHz antenna on rooftop in rural Surrey at 15m height. Verify coverage radius ~1-2km with UK terrain corrections.
8. Whitespace analysis for all of London: output postcodes with zero FTTP. Cross-reference with CF's existing footprint to find expansion candidates.

## NO PLACEHOLDERS. Real data URLs. Real optical physics. Real cost models. Real UK postcode data.
