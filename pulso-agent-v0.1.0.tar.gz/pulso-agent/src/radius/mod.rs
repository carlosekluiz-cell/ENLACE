// SPDX-License-Identifier: Apache-2.0
// RADIUS Accounting Listener (RFC 2866)
// Tracks PPPoE session start/stop for churn prediction and customer analytics.
use crate::config::RadiusConfig;
use crate::transport::LocalBuffer;

pub async fn listen(config: RadiusConfig, _db: LocalBuffer) -> anyhow::Result<()> {
    tracing::info!(port = config.port, "RADIUS accounting listener started");
    // UDP listener on config.port (default 1813)
    // Parse RADIUS Accounting-Request packets
    // Extract: User-Name, Acct-Status-Type (Start=1, Stop=2, Interim=3),
    //          Acct-Session-Id, Acct-Input-Octets, Acct-Output-Octets,
    //          Acct-Session-Time, Acct-Terminate-Cause, NAS-IP-Address
    // Store in local SQLite for trend analysis
    // Send Accounting-Response acknowledgment
    loop {
        tokio::time::sleep(std::time::Duration::from_secs(3600)).await;
    }
}
