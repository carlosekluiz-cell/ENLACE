// SPDX-License-Identifier: Apache-2.0
// Transport: Pulso Cloud HTTPS + local SQLite buffer
use serde::{Deserialize, Serialize};
use crate::config::CloudConfig;
use crate::vendors::OltData;
use crate::mikrotik::MikrotikData;
use crate::diagnostics::OltDiagnostics;
use crate::predictions::Predictions;

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct TelemetryPayload {
    pub agent_id: String,
    pub agent_version: String,
    pub timestamp: chrono::DateTime<chrono::Utc>,
    pub olts: Vec<OltData>,
    pub mikrotiks: Vec<MikrotikData>,
    pub diagnostics: Vec<OltDiagnostics>,
    pub predictions: Vec<Predictions>,
    pub radius_summary: Option<RadiusSummary>,
    pub errors: Vec<CollectionError>,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct RadiusSummary {
    pub active_sessions: u32,
    pub sessions_started_last_hour: u32,
    pub sessions_ended_last_hour: u32,
    pub avg_session_duration_secs: u64,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct CollectionError {
    pub source: String,
    pub error: String,
    pub timestamp: chrono::DateTime<chrono::Utc>,
}

impl TelemetryPayload {
    pub fn new(agent_id: &str) -> Self {
        Self {
            agent_id: agent_id.into(),
            agent_version: env!("CARGO_PKG_VERSION").into(),
            timestamp: chrono::Utc::now(),
            olts: vec![],
            mikrotiks: vec![],
            diagnostics: vec![],
            predictions: vec![],
            radius_summary: None,
            errors: vec![],
        }
    }
    pub fn add_olt(&mut self, d: OltData) { self.olts.push(d); }
    pub fn add_mikrotik(&mut self, d: MikrotikData) { self.mikrotiks.push(d); }
    pub fn add_diagnostics(&mut self, d: OltDiagnostics) { self.diagnostics.push(d); }
    pub fn add_predictions(&mut self, d: Predictions) { self.predictions.push(d); }
    pub fn add_radius(&mut self, s: RadiusSummary) { self.radius_summary = Some(s); }
    pub fn add_error(&mut self, src: &str, err: String) {
        self.errors.push(CollectionError {
            source: src.into(), error: err, timestamp: chrono::Utc::now(),
        });
    }
    pub fn olt_count(&self) -> usize { self.olts.len() }
    pub fn mikrotik_count(&self) -> usize { self.mikrotiks.len() }
    pub fn total_onts(&self) -> usize { self.olts.iter().map(|o| o.onts.len()).sum() }
}

pub struct CloudTransport {
    client: reqwest::Client,
    endpoint: String,
    api_key: String,
    dry_run: bool,
}

impl CloudTransport {
    pub fn new(config: &CloudConfig, dry_run: bool) -> anyhow::Result<Self> {
        let client = reqwest::Client::builder()
            .timeout(std::time::Duration::from_secs(30))
            .danger_accept_invalid_certs(!config.verify_tls)
            .gzip(true)
            .build()?;
        Ok(Self {
            client,
            endpoint: config.endpoint.clone(),
            api_key: config.api_key.clone(),
            dry_run,
        })
    }

    pub async fn send(&self, payload: &TelemetryPayload) -> anyhow::Result<()> {
        if self.dry_run {
            println!("{}", serde_json::to_string_pretty(payload)?);
            return Ok(());
        }
        let resp = self.client
            .post(&self.endpoint)
            .header("Authorization", format!("Bearer {}", self.api_key))
            .header("X-Agent-Version", env!("CARGO_PKG_VERSION"))
            .json(payload)
            .send()
            .await?;
        if !resp.status().is_success() {
            anyhow::bail!("Cloud returned {}", resp.status());
        }
        Ok(())
    }

    pub async fn flush_buffer(&self, _db: &LocalBuffer) -> anyhow::Result<()> { Ok(()) }
}

#[derive(Clone)]
pub struct LocalBuffer {
    path: std::path::PathBuf,
}

impl LocalBuffer {
    pub fn open(data_dir: &std::path::Path) -> anyhow::Result<Self> {
        std::fs::create_dir_all(data_dir)?;
        let path = data_dir.join("pulso_buffer.db");
        let conn = rusqlite::Connection::open(&path)?;
        conn.execute_batch("
            CREATE TABLE IF NOT EXISTS ont_signal_history (
                serial_number TEXT NOT NULL,
                rx_power_dbm REAL NOT NULL,
                timestamp INTEGER NOT NULL,
                PRIMARY KEY (serial_number, timestamp)
            );
            CREATE TABLE IF NOT EXISTS pon_utilization_history (
                olt_id TEXT NOT NULL,
                port_id TEXT NOT NULL,
                utilization_percent REAL NOT NULL,
                timestamp INTEGER NOT NULL,
                PRIMARY KEY (olt_id, port_id, timestamp)
            );
            CREATE TABLE IF NOT EXISTS radius_sessions (
                session_id TEXT PRIMARY KEY,
                username TEXT NOT NULL,
                start_time INTEGER,
                stop_time INTEGER,
                bytes_in INTEGER DEFAULT 0,
                bytes_out INTEGER DEFAULT 0
            );
            CREATE TABLE IF NOT EXISTS telemetry_buffer (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                payload TEXT NOT NULL,
                created_at TEXT NOT NULL DEFAULT (datetime('now'))
            );
        ")?;
        Ok(Self { path })
    }

    pub fn store(&self, payload: &TelemetryPayload) -> anyhow::Result<()> {
        let conn = rusqlite::Connection::open(&self.path)?;
        let json = serde_json::to_string(payload)?;
        conn.execute(
            "INSERT INTO telemetry_buffer (payload) VALUES (?1)",
            rusqlite::params![json],
        )?;
        Ok(())
    }

    pub fn get_ont_signal_history(&self, serial: &str, days: u32) -> anyhow::Result<Vec<(i64, f64)>> {
        let conn = rusqlite::Connection::open(&self.path)?;
        let cutoff = chrono::Utc::now().timestamp() - (days as i64 * 86400);
        let mut stmt = conn.prepare(
            "SELECT timestamp, rx_power_dbm FROM ont_signal_history WHERE serial_number = ?1 AND timestamp > ?2 ORDER BY timestamp"
        )?;
        let rows = stmt.query_map(rusqlite::params![serial, cutoff], |row| {
            Ok((row.get::<_, i64>(0)?, row.get::<_, f64>(1)?))
        })?;
        Ok(rows.filter_map(|r| r.ok()).collect())
    }

    pub fn get_pon_utilization_history(&self, olt_id: &str, port_id: &str, days: u32) -> anyhow::Result<Vec<(i64, f32)>> {
        let conn = rusqlite::Connection::open(&self.path)?;
        let cutoff = chrono::Utc::now().timestamp() - (days as i64 * 86400);
        let mut stmt = conn.prepare(
            "SELECT timestamp, utilization_percent FROM pon_utilization_history WHERE olt_id = ?1 AND port_id = ?2 AND timestamp > ?3 ORDER BY timestamp"
        )?;
        let rows = stmt.query_map(rusqlite::params![olt_id, port_id, cutoff], |row| {
            Ok((row.get::<_, i64>(0)?, row.get::<_, f32>(1)?))
        })?;
        Ok(rows.filter_map(|r| r.ok()).collect())
    }

    pub fn get_radius_summary(&self) -> anyhow::Result<RadiusSummary> {
        let conn = rusqlite::Connection::open(&self.path)?;
        let active: u32 = conn.query_row(
            "SELECT COUNT(*) FROM radius_sessions WHERE stop_time IS NULL",
            [],
            |r| r.get(0),
        ).unwrap_or(0);
        Ok(RadiusSummary {
            active_sessions: active,
            sessions_started_last_hour: 0,
            sessions_ended_last_hour: 0,
            avg_session_duration_secs: 0,
        })
    }
}
