// SPDX-License-Identifier: Apache-2.0
// Network device auto-discovery via SNMP scan.
// Scans management VLAN and identifies OLTs, MikroTik routers, switches.
use serde::{Serialize, Deserialize};
use crate::config::AgentConfig;

#[derive(Debug, Serialize, Deserialize)]
pub struct DiscoveredDevice {
    pub ip: String,
    pub vendor: String,
    pub model: String,
    pub sys_descr: String,
    pub sys_object_id: String,
    pub device_type: String,
}

pub async fn scan_network(_config: &AgentConfig) -> anyhow::Result<Vec<DiscoveredDevice>> {
    // 1. Scan IP range with SNMP GET sysObjectID
    // 2. Match enterprise OID to known vendors
    // 3. Classify as OLT, router, switch, or unknown
    // 4. Try common community strings: "public", "private", vendor defaults
    Ok(vec![])
}
