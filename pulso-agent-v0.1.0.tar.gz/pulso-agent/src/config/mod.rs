// SPDX-License-Identifier: Apache-2.0
// Configuration for the Pulso Agent.
// The ISP fills in their OLT IPs, SNMP credentials, and MikroTik details.
// Credentials are stored locally and NEVER sent to the cloud.

use serde::{Deserialize, Serialize};
use std::path::{Path, PathBuf};
use anyhow::{Context, Result};

#[derive(Debug, Clone, Deserialize, Serialize)]
pub struct AgentConfig {
    /// Unique agent identifier (auto-generated on first run)
    pub agent_id: String,

    /// Directory for local data storage (SQLite buffer, logs)
    #[serde(default = "default_data_dir")]
    pub data_dir: PathBuf,

    /// Polling interval in seconds (default: 60)
    #[serde(default = "default_poll_interval")]
    pub poll_interval_secs: u64,

    /// Pulso Cloud connection settings
    pub cloud: CloudConfig,

    /// OLT devices to monitor
    #[serde(default)]
    pub olts: Vec<OltConfig>,

    /// MikroTik routers to monitor
    #[serde(default)]
    pub mikrotiks: Vec<MikrotikConfig>,

    /// RADIUS accounting listener (optional)
    pub radius: Option<RadiusConfig>,

    /// TR-069 / GenieACS integration (optional)
    pub tr069: Option<Tr069Config>,
}

#[derive(Debug, Clone, Deserialize, Serialize)]
pub struct CloudConfig {
    /// Pulso Cloud API endpoint
    #[serde(default = "default_cloud_endpoint")]
    pub endpoint: String,

    /// API key for authentication (obtained from pulsonetwork.com.br)
    pub api_key: String,

    /// Send interval in seconds (aggregate data before sending)
    #[serde(default = "default_send_interval")]
    pub send_interval_secs: u64,

    /// Enable TLS certificate verification (default: true)
    #[serde(default = "default_true")]
    pub verify_tls: bool,
}

#[derive(Debug, Clone, Deserialize, Serialize)]
pub struct OltConfig {
    /// Human-readable name for this OLT
    pub name: String,

    /// IP address of the OLT management interface
    pub ip: String,

    /// OLT vendor (auto-detected if omitted)
    /// Supported: huawei, zte, fiberhome, intelbras, datacom, parks, bdcom, vsol, cdata, ubiquiti, generic
    #[serde(default = "default_vendor")]
    pub vendor: String,

    /// OLT model (auto-detected if omitted)
    #[serde(default)]
    pub model: String,

    /// SNMP configuration
    pub snmp: Option<SnmpConfig>,

    /// SSH/CLI configuration (for data not available via SNMP)
    pub ssh: Option<SshConfig>,

    /// NETCONF configuration (for Datacom DmOS, Huawei MA5800, ZTE C600+)
    pub netconf: Option<NetconfConfig>,

    /// REST API configuration (for Ubiquiti UISP)
    pub rest_api: Option<RestApiConfig>,
}

#[derive(Debug, Clone, Deserialize, Serialize)]
pub struct SnmpConfig {
    /// SNMP version: "v2c" or "v3"
    #[serde(default = "default_snmp_version")]
    pub version: String,

    /// Community string (for v2c)
    pub community: Option<String>,

    /// SNMPv3 credentials
    pub v3: Option<SnmpV3Config>,

    /// SNMP port (default: 161)
    #[serde(default = "default_snmp_port")]
    pub port: u16,

    /// Timeout in milliseconds (default: 5000)
    #[serde(default = "default_snmp_timeout")]
    pub timeout_ms: u64,

    /// Maximum OIDs per GetBulk request (default: 50)
    #[serde(default = "default_max_repetitions")]
    pub max_repetitions: u32,
}

#[derive(Debug, Clone, Deserialize, Serialize)]
pub struct SnmpV3Config {
    pub username: String,
    pub auth_protocol: Option<String>,  // MD5, SHA, SHA256
    pub auth_password: Option<String>,
    pub priv_protocol: Option<String>,  // DES, AES128, AES256
    pub priv_password: Option<String>,
}

#[derive(Debug, Clone, Deserialize, Serialize)]
pub struct SshConfig {
    pub username: String,
    /// Password or path to SSH key file
    pub password: Option<String>,
    pub key_file: Option<PathBuf>,
    #[serde(default = "default_ssh_port")]
    pub port: u16,
    /// Enable CLI scraping (default: true, set false to disable for this OLT)
    #[serde(default = "default_true")]
    pub enabled: bool,
}

#[derive(Debug, Clone, Deserialize, Serialize)]
pub struct NetconfConfig {
    pub username: String,
    pub password: Option<String>,
    pub key_file: Option<PathBuf>,
    #[serde(default = "default_netconf_port")]
    pub port: u16,
}

#[derive(Debug, Clone, Deserialize, Serialize)]
pub struct RestApiConfig {
    pub base_url: String,
    pub api_key: Option<String>,
    pub username: Option<String>,
    pub password: Option<String>,
}

#[derive(Debug, Clone, Deserialize, Serialize)]
pub struct MikrotikConfig {
    pub name: String,
    pub ip: String,
    #[serde(default = "default_mikrotik_port")]
    pub port: u16,
    pub username: String,
    pub password: String,
    /// Collect PPPoE session data (default: true)
    #[serde(default = "default_true")]
    pub collect_pppoe: bool,
    /// Collect BGP session data (default: true)
    #[serde(default = "default_true")]
    pub collect_bgp: bool,
    /// Collect interface traffic (default: true)
    #[serde(default = "default_true")]
    pub collect_interfaces: bool,
    /// Collect queue/bandwidth data (default: true)
    #[serde(default = "default_true")]
    pub collect_queues: bool,
}

#[derive(Debug, Clone, Deserialize, Serialize)]
pub struct RadiusConfig {
    /// Listen port for RADIUS accounting (default: 1813)
    #[serde(default = "default_radius_port")]
    pub port: u16,
    /// Shared secret for RADIUS packets
    pub secret: String,
    /// Listen address (default: 0.0.0.0)
    #[serde(default = "default_listen_addr")]
    pub listen_addr: String,
}

#[derive(Debug, Clone, Deserialize, Serialize)]
pub struct Tr069Config {
    /// GenieACS API endpoint (e.g., http://localhost:7557)
    pub genieacs_url: String,
    /// GenieACS credentials (optional)
    pub username: Option<String>,
    pub password: Option<String>,
    /// Poll interval for TR-069 data (default: 300 seconds)
    #[serde(default = "default_tr069_interval")]
    pub poll_interval_secs: u64,
}

// Defaults
fn default_data_dir() -> PathBuf { PathBuf::from("/var/lib/pulso-agent") }
fn default_poll_interval() -> u64 { 60 }
fn default_cloud_endpoint() -> String { "https://api.pulsonetwork.com.br/v1/telemetry".into() }
fn default_send_interval() -> u64 { 300 }
fn default_true() -> bool { true }
fn default_vendor() -> String { "auto".into() }
fn default_snmp_version() -> String { "v2c".into() }
fn default_snmp_port() -> u16 { 161 }
fn default_snmp_timeout() -> u64 { 5000 }
fn default_max_repetitions() -> u32 { 50 }
fn default_ssh_port() -> u16 { 22 }
fn default_netconf_port() -> u16 { 830 }
fn default_mikrotik_port() -> u16 { 8728 }
fn default_radius_port() -> u16 { 1813 }
fn default_listen_addr() -> String { "0.0.0.0".into() }
fn default_tr069_interval() -> u64 { 300 }

impl AgentConfig {
    pub fn load(path: &Path) -> Result<Self> {
        if path.exists() {
            let content = std::fs::read_to_string(path)
                .with_context(|| format!("Failed to read config: {:?}", path))?;
            let mut cfg: AgentConfig = toml::from_str(&content)
                .with_context(|| "Failed to parse config TOML")?;

            // Auto-generate agent_id if not set
            if cfg.agent_id.is_empty() {
                cfg.agent_id = uuid::Uuid::new_v4().to_string();
                // Save back with generated ID
                let updated = toml::to_string_pretty(&cfg)?;
                std::fs::write(path, updated)?;
            }

            Ok(cfg)
        } else {
            // Generate example config for the ISP
            let example = Self::example();
            let dir = path.parent().unwrap_or(Path::new("/etc/pulso"));
            std::fs::create_dir_all(dir)?;
            let content = toml::to_string_pretty(&example)?;
            std::fs::write(path, &content)?;
            println!("Example configuration written to {:?}", path);
            println!("Please edit the file with your OLT and router details, then restart.");
            println!();
            println!("Quick start:");
            println!("  1. Set your Pulso API key (from pulsonetwork.com.br)");
            println!("  2. Add your OLT IP and SNMP community string");
            println!("  3. Add your MikroTik IP and credentials");
            println!("  4. Run: pulso-agent -v");
            std::process::exit(0);
        }
    }

    fn example() -> Self {
        AgentConfig {
            agent_id: String::new(),
            data_dir: default_data_dir(),
            poll_interval_secs: 60,
            cloud: CloudConfig {
                endpoint: default_cloud_endpoint(),
                api_key: "YOUR_API_KEY_FROM_PULSONETWORK".into(),
                send_interval_secs: 300,
                verify_tls: true,
            },
            olts: vec![OltConfig {
                name: "OLT-Principal".into(),
                ip: "10.0.0.1".into(),
                vendor: "auto".into(),
                model: String::new(),
                snmp: Some(SnmpConfig {
                    version: "v2c".into(),
                    community: Some("public".into()),
                    v3: None,
                    port: 161,
                    timeout_ms: 5000,
                    max_repetitions: 50,
                }),
                ssh: Some(SshConfig {
                    username: "admin".into(),
                    password: Some("admin".into()),
                    key_file: None,
                    port: 22,
                    enabled: true,
                }),
                netconf: None,
                rest_api: None,
            }],
            mikrotiks: vec![MikrotikConfig {
                name: "MK-Core".into(),
                ip: "10.0.0.254".into(),
                port: 8728,
                username: "pulso".into(),
                password: "CHANGE_ME".into(),
                collect_pppoe: true,
                collect_bgp: true,
                collect_interfaces: true,
                collect_queues: true,
            }],
            radius: None,
            tr069: None,
        }
    }
}
