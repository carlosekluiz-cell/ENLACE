// SPDX-License-Identifier: Apache-2.0
// Copyright 2026 Pulso Network (pulsonetwork.com.br)
//
// Pulso Agent — Open-source, vendor-agnostic ISP network intelligence collector.
//
// This agent runs INSIDE the ISP's network and collects telemetry from:
//   • OLTs via SNMP + SSH CLI (Huawei, ZTE, FiberHome, Datacom, Intelbras, Parks, BDCOM, VSOL, CDATA, Ubiquiti)
//   • MikroTik routers via RouterOS API (TCP 8728)
//   • RADIUS accounting (UDP 1813)
//   • TR-069/CWMP CPE data (via GenieACS integration)
//
// Data flows ONE WAY: ISP network → Pulso Cloud (HTTPS).
// Credentials NEVER leave the ISP's network.
// The agent is read-only — it never modifies OLT, router, or CPE configuration.
//
// Architecture:
//   ┌─────────────────────────────────────┐
//   │         ISP's Local Network          │
//   │                                      │
//   │  ┌─────┐  ┌─────────┐  ┌────────┐  │
//   │  │ OLT │  │MikroTik │  │ RADIUS │  │
//   │  └──┬──┘  └────┬────┘  └───┬────┘  │
//   │     │SNMP/SSH   │API 8728   │UDP1813│
//   │     └─────┬─────┴─────┬─────┘       │
//   │           │           │              │
//   │     ┌─────▼───────────▼─────┐       │
//   │     │    PULSO AGENT        │       │
//   │     │  (this binary, ~8MB)  │       │
//   │     │  ┌─────────────────┐  │       │
//   │     │  │ Local SQLite    │  │       │
//   │     │  │ (offline buffer)│  │       │
//   │     │  └─────────────────┘  │       │
//   │     └───────────┬───────────┘       │
//   │                 │ HTTPS (port 443)  │
//   └─────────────────┼──────────────────-┘
//                     │
//            ┌────────▼────────┐
//            │  PULSO CLOUD    │
//            │  (proprietary)  │
//            │  37+ data sources│
//            │  Intelligence    │
//            │  Predictions     │
//            │  Dashboard       │
//            └─────────────────┘

use clap::Parser;
use std::path::PathBuf;
use tracing::{info, warn, error};

mod config;
mod snmp;
mod vendors;
mod mikrotik;
mod radius;
mod transport;
mod discovery;
mod diagnostics;
mod predictions;

/// Pulso Agent — ISP Network Intelligence Collector
/// Open-source, vendor-agnostic, built in Rust for performance at scale.
/// Monitors OLTs, MikroTik routers, RADIUS sessions, and CPE devices.
/// Sends telemetry to Pulso Network cloud for intelligence fusion.
#[derive(Parser, Debug)]
#[command(name = "pulso-agent", version, about)]
struct Args {
    /// Path to configuration file
    #[arg(short, long, default_value = "/etc/pulso/agent.toml")]
    config: PathBuf,

    /// Run in discovery mode (scan network for devices, then exit)
    #[arg(long)]
    discover: bool,

    /// Run a single collection cycle and exit (useful for testing)
    #[arg(long)]
    once: bool,

    /// Print collected data to stdout instead of sending to cloud
    #[arg(long)]
    dry_run: bool,

    /// Verbosity level (-v info, -vv debug, -vvv trace)
    #[arg(short, long, action = clap::ArgAction::Count)]
    verbose: u8,
}

#[tokio::main]
async fn main() -> anyhow::Result<()> {
    let args = Args::parse();

    // Initialize structured logging
    let log_level = match args.verbose {
        0 => "warn",
        1 => "info",
        2 => "debug",
        _ => "trace",
    };
    tracing_subscriber::fmt()
        .with_env_filter(
            tracing_subscriber::EnvFilter::try_from_default_env()
                .unwrap_or_else(|_| tracing_subscriber::EnvFilter::new(log_level)),
        )
        .with_target(false)
        .json()
        .init();

    info!(
        version = env!("CARGO_PKG_VERSION"),
        "Pulso Agent starting"
    );

    // Load configuration
    let cfg = config::AgentConfig::load(&args.config)?;
    info!(
        agent_id = %cfg.agent_id,
        cloud_endpoint = %cfg.cloud.endpoint,
        olt_count = cfg.olts.len(),
        mikrotik_count = cfg.mikrotiks.len(),
        "Configuration loaded"
    );

    // Initialize local SQLite buffer for offline resilience
    let db = transport::LocalBuffer::open(&cfg.data_dir)?;
    info!("Local buffer initialized at {:?}", cfg.data_dir);

    // Initialize cloud transport
    let cloud = transport::CloudTransport::new(&cfg.cloud, args.dry_run)?;

    // Phase 1: Device Discovery (if requested or first run)
    if args.discover {
        info!("Running network discovery...");
        let discovered = discovery::scan_network(&cfg).await?;
        for device in &discovered {
            info!(
                ip = %device.ip,
                vendor = %device.vendor,
                model = %device.model,
                "Discovered device"
            );
        }
        println!("{}", serde_json::to_string_pretty(&discovered)?);
        return Ok(());
    }

    // Phase 2: Initialize vendor-specific collectors
    let mut olt_collectors: Vec<Box<dyn vendors::OltCollector>> = Vec::new();

    for olt_cfg in &cfg.olts {
        match vendors::create_collector(olt_cfg) {
            Ok(collector) => {
                info!(
                    ip = %olt_cfg.ip,
                    vendor = %olt_cfg.vendor,
                    "OLT collector initialized"
                );
                olt_collectors.push(collector);
            }
            Err(e) => {
                warn!(
                    ip = %olt_cfg.ip,
                    vendor = %olt_cfg.vendor,
                    error = %e,
                    "Failed to initialize OLT collector, will use generic SNMP"
                );
                // Fall back to generic IF-MIB collector
                olt_collectors.push(Box::new(vendors::generic::GenericCollector::new(olt_cfg)));
            }
        }
    }

    // Initialize MikroTik collectors
    let mut mk_collectors: Vec<mikrotik::MikrotikCollector> = Vec::new();
    for mk_cfg in &cfg.mikrotiks {
        match mikrotik::MikrotikCollector::new(mk_cfg).await {
            Ok(collector) => {
                info!(ip = %mk_cfg.ip, "MikroTik collector initialized");
                mk_collectors.push(collector);
            }
            Err(e) => {
                warn!(ip = %mk_cfg.ip, error = %e, "Failed to initialize MikroTik collector");
            }
        }
    }

    // Initialize RADIUS listener (if configured)
    let radius_handle = if let Some(ref radius_cfg) = cfg.radius {
        info!(port = radius_cfg.port, "Starting RADIUS accounting listener");
        Some(tokio::spawn(radius::listen(radius_cfg.clone(), db.clone())))
    } else {
        None
    };

    // Phase 3: Main collection loop
    info!("Entering main collection loop (interval: {}s)", cfg.poll_interval_secs);

    let mut interval = tokio::time::interval(
        std::time::Duration::from_secs(cfg.poll_interval_secs)
    );

    loop {
        interval.tick().await;

        let cycle_start = std::time::Instant::now();
        let mut telemetry = transport::TelemetryPayload::new(&cfg.agent_id);

        // Collect from all OLTs
        for collector in &olt_collectors {
            match collector.collect().await {
                Ok(data) => {
                    // Run diagnostics on collected ONT data
                    let diag = diagnostics::analyze_olt(&data);
                    // Run predictions on historical data
                    let preds = predictions::forecast_olt(&data, &db);

                    telemetry.add_olt(data);
                    telemetry.add_diagnostics(diag);
                    telemetry.add_predictions(preds);
                }
                Err(e) => {
                    warn!(
                        olt = %collector.olt_id(),
                        error = %e,
                        "OLT collection failed"
                    );
                    telemetry.add_error(collector.olt_id(), e.to_string());
                }
            }
        }

        // Collect from all MikroTik routers
        for collector in &mk_collectors {
            match collector.collect().await {
                Ok(data) => {
                    telemetry.add_mikrotik(data);
                }
                Err(e) => {
                    warn!(
                        mikrotik = %collector.router_id(),
                        error = %e,
                        "MikroTik collection failed"
                    );
                }
            }
        }

        // Add RADIUS session summary from local buffer
        if cfg.radius.is_some() {
            if let Ok(sessions) = db.get_radius_summary() {
                telemetry.add_radius(sessions);
            }
        }

        let elapsed = cycle_start.elapsed();
        info!(
            olts = telemetry.olt_count(),
            onts = telemetry.total_onts(),
            mikrotiks = telemetry.mikrotik_count(),
            elapsed_ms = elapsed.as_millis() as u64,
            "Collection cycle complete"
        );

        // Send to cloud (or buffer locally if offline)
        match cloud.send(&telemetry).await {
            Ok(_) => {
                info!("Telemetry sent to Pulso Cloud");
                // Also try to flush any buffered data from previous offline periods
                if let Err(e) = cloud.flush_buffer(&db).await {
                    warn!(error = %e, "Failed to flush offline buffer");
                }
            }
            Err(e) => {
                warn!(error = %e, "Cloud unreachable, buffering locally");
                if let Err(e) = db.store(&telemetry) {
                    error!(error = %e, "Failed to buffer telemetry locally");
                }
            }
        }

        if args.once {
            info!("Single collection cycle complete, exiting");
            break;
        }
    }

    // Cleanup
    if let Some(handle) = radius_handle {
        handle.abort();
    }

    info!("Pulso Agent shutting down");
    Ok(())
}
