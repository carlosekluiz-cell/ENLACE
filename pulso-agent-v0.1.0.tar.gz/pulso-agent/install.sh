#!/bin/bash
# Pulso Agent Installer
# https://pulsonetwork.com.br
#
# Usage: curl -sL https://pulsonetwork.com.br/install.sh | bash
#
# This script:
# 1. Downloads the Pulso Agent binary for your architecture
# 2. Installs it to /usr/local/bin/
# 3. Creates default config at /etc/pulso/agent.toml
# 4. Sets up systemd service

set -e

AGENT_VERSION="0.1.0"
BASE_URL="https://releases.pulsonetwork.com.br/agent"

echo "╔══════════════════════════════════════════╗"
echo "║     Pulso Agent Installer v${AGENT_VERSION}         ║"
echo "║     pulsonetwork.com.br                  ║"
echo "╚══════════════════════════════════════════╝"
echo ""

# Detect architecture
ARCH=$(uname -m)
case "$ARCH" in
    x86_64)  BINARY="pulso-agent-linux-x86_64" ;;
    aarch64) BINARY="pulso-agent-linux-arm64" ;;
    armv7l)  BINARY="pulso-agent-linux-armv7" ;;
    *)       echo "Unsupported architecture: $ARCH"; exit 1 ;;
esac

echo "Detected: $ARCH"
echo "Downloading Pulso Agent..."

# Download binary
curl -fSL "${BASE_URL}/${AGENT_VERSION}/${BINARY}" -o /tmp/pulso-agent
chmod +x /tmp/pulso-agent

# Install
sudo mv /tmp/pulso-agent /usr/local/bin/pulso-agent
echo "✓ Installed to /usr/local/bin/pulso-agent"

# Create config directory
sudo mkdir -p /etc/pulso /var/lib/pulso-agent

# Generate example config if not exists
if [ ! -f /etc/pulso/agent.toml ]; then
    pulso-agent --config /etc/pulso/agent.toml 2>/dev/null || true
    echo "✓ Example config created at /etc/pulso/agent.toml"
fi

# Create systemd service
sudo tee /etc/systemd/system/pulso-agent.service > /dev/null << EOF
[Unit]
Description=Pulso Agent — ISP Network Intelligence Collector
After=network.target

[Service]
Type=simple
ExecStart=/usr/local/bin/pulso-agent -v --config /etc/pulso/agent.toml
Restart=always
RestartSec=10
User=root
WorkingDirectory=/var/lib/pulso-agent

[Install]
WantedBy=multi-user.target
EOF

sudo systemctl daemon-reload
echo "✓ Systemd service created"

echo ""
echo "═══════════════════════════════════════════"
echo "  Next steps:"
echo ""
echo "  1. Edit config:   sudo nano /etc/pulso/agent.toml"
echo "     - Set your API key (from pulsonetwork.com.br)"
echo "     - Add your OLT IP and SNMP community"
echo "     - Add your MikroTik IP and credentials"
echo ""
echo "  2. Test:           pulso-agent -vv --once --dry-run"
echo ""
echo "  3. Start service:  sudo systemctl enable --now pulso-agent"
echo ""
echo "  Docs: https://pulsonetwork.com.br/docs/agent"
echo "═══════════════════════════════════════════"
