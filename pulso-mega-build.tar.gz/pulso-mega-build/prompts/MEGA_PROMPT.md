# PULSO MEGA BUILD — Complete Platform Upgrade

Read this entire prompt before doing anything. This is a large build with multiple phases.
Execute each phase in order. Test after each phase before moving to the next.

## OVERVIEW

This prompt upgrades PULSO from a design engine into a complete platform that rivals 
Comsof (design), Nokia AVA (telemetry), and Atoll (propagation) — combined in one system.

Phases:
1. Antenna Pattern Library (MSI parser + database)
2. Additional Propagation Models (Okumura-Hata, COST 231)
3. Build Pack Generator (BOM, schematics, trenching plans, splice documentation)
4. 3D Web Viewer (Deck.gl + MapLibre + terrain + buildings + fibre routes)
5. Interactive Design Editor (drag splitters, drag routes, live recalculation)
6. Export Engine (GeoJSON, Shapefile, KML, XLSX BOM, PDF schematic, DXF)
7. FWA-vs-Fibre Decision Engine (automated per-premises using EPC + propagation)
8. Integration Test (blind design of entire Grahame Park estate, compare to real CF schematic)

Total estimated: ~35-40 hours of Claude Code work across multiple sessions.
For this session: prioritise Phases 1, 2, 3, and 7 (core engineering).
Phases 4, 5, 6 are frontend/export (can be done in a later session).

---

## PHASE 1: ANTENNA PATTERN LIBRARY (~300 lines Rust)

### 1A: MSI File Parser

Create: `rust/crates/enlace-propagation/src/antenna.rs`

The MSI Planet format is ASCII text:
```
NAME antenna_name
MAKE manufacturer
FREQUENCY freq_mhz
GAIN gain_dbd
COMMENT text
HORIZONTAL 360
0 0.0
1 0.3
2 0.8
...
359 0.1
VERTICAL 360
0 0.0
1 2.5
...
359 0.2
```

```rust
pub struct AntennaPattern {
    pub name: String,
    pub make: String,
    pub frequency_mhz: f64,
    pub gain_dbi: f64,           // convert from dBd if needed: dBi = dBd + 2.15
    pub comment: String,
    pub horizontal: Vec<f64>,    // 360 values, gain relative to max in dB
    pub vertical: Vec<f64>,      // 360 values, gain relative to max in dB
}

impl AntennaPattern {
    /// Parse MSI format file
    pub fn from_msi(reader: impl Read) -> Result<Self> { ... }
    
    /// Get gain at specific azimuth and elevation angles (interpolated)
    pub fn gain_at(&self, azimuth_deg: f64, elevation_deg: f64) -> f64 { ... }
    
    /// Get effective gain toward a target given antenna orientation
    pub fn effective_gain(
        &self,
        antenna_azimuth: f64,    // antenna pointing direction
        antenna_tilt: f64,       // mechanical + electrical downtilt
        target_azimuth: f64,     // direction to target from antenna
        target_elevation: f64,   // elevation angle to target
    ) -> f64 { ... }
    
    /// Get horizontal beamwidth (-3dB points)
    pub fn h_beamwidth(&self) -> f64 { ... }
    
    /// Get vertical beamwidth (-3dB points)
    pub fn v_beamwidth(&self) -> f64 { ... }
    
    /// Get front-to-back ratio in dB
    pub fn front_to_back_db(&self) -> f64 { ... }
}
```

### 1B: Antenna Database

```rust
pub struct AntennaDatabase {
    patterns: HashMap<String, AntennaPattern>,  // key: "make/model/freq"
}

impl AntennaDatabase {
    /// Load all .msi files from a directory tree
    pub fn load_dir(path: &Path) -> Result<Self> { ... }
    
    /// Find antenna by make and model (fuzzy match)
    pub fn find(&self, make: &str, model: &str, freq_mhz: f64) -> Option<&AntennaPattern> { ... }
    
    /// List all antennas for a manufacturer
    pub fn list_by_make(&self, make: &str) -> Vec<&AntennaPattern> { ... }
    
    /// Get default omnidirectional pattern for a given gain
    pub fn omnidirectional(gain_dbi: f64) -> AntennaPattern { ... }
    
    /// Get default sectoral pattern (120° beamwidth) for a given gain
    pub fn sectoral_120(gain_dbi: f64) -> AntennaPattern { ... }
}
```

### 1C: Integration with Propagation Engine

Update the link budget calculation to use antenna patterns:
```rust
pub fn link_budget_with_antenna(
    tx_power_dbm: f64,
    antenna: &AntennaPattern,
    antenna_azimuth: f64,
    antenna_tilt: f64,
    target_azimuth: f64,
    target_elevation: f64,
    path_loss_db: f64,
    rx_antenna_gain_dbi: f64,    // CPE antenna
    additional_losses_db: f64,   // cable loss, BEL, etc
) -> LinkBudgetResult { ... }
```

Tests:
- Parse a real MSI file (include a sample in test data)
- Verify gain_at(0, 0) returns 0 dB (boresight = max gain)
- Verify gain_at(180, 0) returns front-to-back ratio
- Verify h_beamwidth matches file header value
- Verify link budget with antenna vs without (should differ by pattern gain)
- Test omnidirectional pattern: gain_at any angle ≈ 0 dB relative

---

## PHASE 2: ADDITIONAL PROPAGATION MODELS (~200 lines Rust)

### 2A: Okumura-Hata Model

Create: `rust/crates/enlace-propagation/src/okumura_hata.rs`

Standard Okumura-Hata for 150-1500 MHz:
```rust
pub enum HataEnvironment {
    Urban,
    Suburban,
    Rural,
}

/// Okumura-Hata path loss in dB
/// f: frequency in MHz (150-1500)
/// d: distance in km (1-20)
/// h_b: base station height in m (30-200)
/// h_m: mobile height in m (1-10)
pub fn okumura_hata(
    f: f64, d: f64, h_b: f64, h_m: f64, 
    env: HataEnvironment
) -> f64 {
    // Urban formula:
    // L = 69.55 + 26.16*log10(f) - 13.82*log10(h_b) - a(h_m) + (44.9 - 6.55*log10(h_b))*log10(d)
    // where a(h_m) is the mobile antenna correction factor
    
    // For medium-small city:
    // a(h_m) = (1.1*log10(f) - 0.7)*h_m - (1.56*log10(f) - 0.8)
    
    // For large city:
    // a(h_m) = 8.29*(log10(1.54*h_m))^2 - 1.1  for f <= 200 MHz
    // a(h_m) = 3.2*(log10(11.75*h_m))^2 - 4.97  for f >= 400 MHz
    
    // Suburban correction: L_sub = L_urban - 2*(log10(f/28))^2 - 5.4
    // Rural correction: L_rural = L_urban - 4.78*(log10(f))^2 + 18.33*log10(f) - 40.94
}
```

### 2B: COST 231 Hata Extension

```rust
/// COST 231 extension of Hata for 1500-2000 MHz
/// Same interface as okumura_hata but valid for higher frequencies
pub fn cost231_hata(
    f: f64, d: f64, h_b: f64, h_m: f64,
    env: HataEnvironment
) -> f64 {
    // L = 46.3 + 33.9*log10(f) - 13.82*log10(h_b) - a(h_m) 
    //     + (44.9 - 6.55*log10(h_b))*log10(d) + C_m
    // where C_m = 0 dB for medium city/suburban, 3 dB for metropolitan
}
```

### 2C: Brazilian Biome Corrections for Hata

Add the PULSO proprietary biome corrections to the Hata models:
```rust
pub fn hata_with_biome(
    f: f64, d: f64, h_b: f64, h_m: f64,
    env: HataEnvironment,
    biome: BrazilianBiome,
) -> f64 {
    let base = if f <= 1500.0 { okumura_hata(f, d, h_b, h_m, env) }
               else { cost231_hata(f, d, h_b, h_m, env) };
    base + biome.correction_db(f)
}
```

Tests:
- Okumura-Hata urban 900MHz 5km: verify against known reference (~140 dB)
- Okumura-Hata rural 700MHz 10km: verify (~120 dB)
- COST 231 urban 1800MHz 2km: verify (~130 dB)
- Suburban correction reduces loss by ~10 dB vs urban
- Rural correction reduces loss by ~20 dB vs urban
- Brazilian cerrado at 700MHz adds 4-8 dB
- Amazon canopy at 700MHz adds 15-30 dB

---

## PHASE 3: BUILD PACK GENERATOR (~500 lines Rust)

This is what Comsof delivers that PULSO needs to match: complete to-build documentation.

### 3A: Enhanced BOM with Full Material Specification

Extend the existing bom.rs to include detailed material specs:

```rust
pub struct DetailedBOM {
    // Cable schedule
    pub cables: Vec<CableEntry>,
    // Equipment schedule
    pub equipment: Vec<EquipmentEntry>,
    // Civils schedule
    pub civils: Vec<CivilsEntry>,
    // Labour schedule
    pub labour: Vec<LabourEntry>,
    // Summary
    pub total_cable_metres: f64,
    pub total_fibre_km: f64,
    pub total_civils_metres: f64,
    pub total_premises: u32,
    pub total_capex: f64,
    pub capex_per_premises: f64,
}

pub struct CableEntry {
    pub segment_id: String,      // e.g. "FC2100"
    pub from_location: String,   // e.g. "AUX JC2218"
    pub to_location: String,     // e.g. "Napier House"
    pub cable_type: String,      // e.g. "12F SM G.657"
    pub length_m: f64,
    pub route_type: RouteType,   // PIA_duct, new_build_footway, new_build_verge, aerial, catenary
    pub unit_cost_per_m: f64,
    pub total_cost: f64,
}

pub struct EquipmentEntry {
    pub location: String,
    pub equipment_type: String,   // e.g. "64-way splitter box"
    pub model: String,            // e.g. "Large Splitter Box 376x182x500mm"
    pub quantity: u32,
    pub unit_cost: f64,
    pub total_cost: f64,
}

pub struct CivilsEntry {
    pub work_point_id: String,    // e.g. "WP1"
    pub description: String,      // e.g. "Core drill from BT chamber to Rapide MDU base"
    pub civils_type: CivilsType,  // core_drill, new_duct_footway, new_duct_verge, upturn_90deg
    pub length_m: f64,
    pub unit_cost_per_m: f64,
    pub total_cost: f64,
}
```

### 3B: Fibre Connection Plan Generator

Generate the fibre-level splice documentation matching CF format:

```rust
pub struct FibreConnectionPlan {
    pub project_id: String,
    pub joints: Vec<JointDetail>,
}

pub struct JointDetail {
    pub joint_id: String,          // e.g. "JC2218"
    pub joint_type: String,        // AUX Joint, Splitter Box, PBO
    pub location: String,
    pub incoming_cables: Vec<CableConnection>,
    pub outgoing_cables: Vec<CableConnection>,
    pub splitter: Option<SplitterDetail>,
    pub fibre_assignments: Vec<FibreAssignment>,
}

pub struct FibreAssignment {
    pub incoming_cable: String,
    pub incoming_fibre: u32,
    pub destination: String,        // "SB1 F1 in" or "FC2102 F3" (pass-through)
    pub splice_type: String,        // "Fusion" or "Mechanical"
}
```

### 3C: Trenching Plan Generator

```rust
pub struct TrenchingPlan {
    pub segments: Vec<TrenchSegment>,
    pub total_length_m: f64,
    pub total_cost: f64,
}

pub struct TrenchSegment {
    pub segment_id: String,
    pub from: String,
    pub to: String,
    pub length_m: f64,
    pub surface_type: SurfaceType,  // footway, verge, carriageway
    pub duct_spec: String,          // "54mm 1W" or "96mm 2W" or "PIA micro-duct 12/8mm"
    pub depth_mm: u32,              // typically 450mm footway, 600mm carriageway
    pub width_mm: u32,              // typically 150mm single duct
    pub reinstatement: String,      // "Type A modular", "Type B flexible", etc
    pub traffic_management: bool,
    pub estimated_duration_hours: f64,
}
```

### 3D: PDF Build Pack Exporter

Generate a PDF matching CF wayleave pack format:
- Cover page with project details
- Hazard identification checklist
- Equipment specifications with images/dimensions
- PIA usage map overview
- Civils overview map with work points
- Per-building blockwire plans
- Cable feed GIS design map
- Fibre connection schematics
- BOM summary
- Cost estimate

Use reportlab for PDF generation. The schematic diagrams can be SVG rendered 
and embedded in the PDF.

Tests:
- Generate complete build pack for Grahame Park
- BOM total cable: verify ~1,200m (within 20% of real CF)
- BOM splitter count: verify 15 total
- Cost per premises: verify £200-500 range
- Fibre connection plan: verify splice assignments follow CF convention
- PDF generates without errors, all pages present

---

## PHASE 7: FWA-vs-FIBRE DECISION ENGINE (~200 lines Rust)

This uses the EPC building classification + propagation engine to automatically 
decide the optimal connection method for every premises.

### 7A: Per-Premises Decision

```rust
pub enum ConnectionMethod {
    Fibre,              // FTTP - always viable, higher CAPEX
    FwaOutdoorCpe,      // External CPE on wall/roof - viable if signal sufficient
    FwaIndoorCpe,       // Indoor CPE - only viable with low BEL
    HybridFibreToDP,    // Fibre to distribution point, FWA last mile
    NotViable,          // Too remote for either
}

pub struct ConnectionDecision {
    pub premises_id: String,
    pub postcode: String,
    pub building_type: UkBuildingType,
    pub method: ConnectionMethod,
    pub fibre_capex: f64,
    pub fwa_capex: f64,
    pub savings_if_fwa: f64,
    pub fwa_snr_db: f64,
    pub fwa_throughput_mbps: f64,
    pub fibre_optical_budget_margin_db: f64,
    pub reasoning: String,
}

pub fn decide_connection(
    premises: &PremisesInfo,
    nearest_pop: &PopInfo,
    nearest_fwa_site: Option<&FwaSiteInfo>,
    propagation_model: &PropagationModel,
    cost_model: &UkCostRates,
) -> ConnectionDecision {
    // 1. Calculate fibre CAPEX (distance to POP × per-metre cost + equipment)
    // 2. If FWA site exists within range:
    //    a. Calculate path loss using TR 38.901 or Hata
    //    b. Get BEL from EPC building type
    //    c. Calculate indoor SNR
    //    d. If SNR > threshold for target throughput: FWA viable
    //    e. Compare FWA CAPEX (CPE + installation) vs fibre CAPEX
    // 3. Choose lowest CAPEX method that meets service requirement
    // 4. Return decision with full reasoning
}
```

### 7B: Area-Wide Decision Map

```rust
pub struct AreaDecisionMap {
    pub area_name: String,
    pub total_premises: u32,
    pub fibre_premises: u32,
    pub fwa_outdoor_premises: u32,
    pub fwa_indoor_premises: u32,
    pub hybrid_premises: u32,
    pub total_fibre_capex: f64,
    pub total_fwa_capex: f64,
    pub total_hybrid_capex: f64,
    pub total_optimised_capex: f64,
    pub savings_vs_all_fibre: f64,
    pub savings_percentage: f64,
    pub decisions: Vec<ConnectionDecision>,
}

/// Run FWA-vs-fibre analysis for an entire area
pub fn analyse_area(
    postcodes: &[PostcodeInfo],
    pops: &[PopInfo],
    fwa_sites: &[FwaSiteInfo],
    epc_data: &[EpcRecord],
    propagation_model: &PropagationModel,
    cost_model: &UkCostRates,
) -> AreaDecisionMap { ... }
```

Tests:
- Victorian terraces at 500m from FWA site, 3.5GHz: decide FIBRE (BEL too high)
- Modern new-build at 500m from FWA site: decide FWA_OUTDOOR (BEL low enough)
- Rural scattered at 8km from POP, 2km from FWA site: decide FWA_OUTDOOR
- Council estate 1960s concrete: decide FIBRE (matches Grahame Park reality)
- Area analysis: verify savings percentage is 5-15% vs all-fibre approach
- Grahame Park NW9 5UN: ALL should be FIBRE (confirms CF's actual decision)

---

## PHASE 8: INTEGRATION TEST — BLIND GRAHAME PARK

After all phases complete, run the ultimate test:

Input: "NW9 5UN"
The system must:
1. Load EPC data → classify buildings → assign BEL
2. Load AddressBase data → exact coordinates and dwelling counts
3. Detect estate boundary → filter to 15 MDU blocks
4. Run FWA-vs-fibre decision → ALL should be FIBRE
5. Generate fibre topology → splitters, chains, PBOs
6. Calculate optical budgets → all must pass
7. Generate complete build pack: BOM, splice plan, trenching plan, cost estimate
8. Output comparison against real CF Project ID 4610

Target metrics:
- Building detection: 100% (15/15)
- Splitter match: 87%+ (13/15)
- PBO detection: 100% (3/3)
- Optical budget: ALL PASS
- FWA decision: ALL FIBRE (matches reality)
- BOM within 20% of actual
- Cost estimate within reasonable range

Show complete output including build pack documentation.

