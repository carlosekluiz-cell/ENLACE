# Data Sources for PULSO Platform

## Antenna Patterns
- MSI Library (400K files): https://www.wireless-planning.com/msi-antenna-pattern-file-library
- CloudRF patterns: https://cloudrf.com/docs/antenna-patterns/
- MSI format spec: http://radiomobile.pe1mew.nl/?The_program___Definitions___MSI=
- Perl MSI parser: https://github.com/mrdvt92/perl-RF-Antenna-Planet-MSI-Format

## UK Open Data
- OS Data Hub: https://osdatahub.os.uk/
- OS OpenUPRN (free): https://osdatahub.os.uk/downloads/open/OpenUPRN
- OS Open Roads (free): https://osdatahub.os.uk/downloads/open/OpenRoads
- EPC data: https://epc.opendatacommunities.org/
- Ofcom Connected Nations: https://www.ofcom.org.uk/research-and-data/telecoms-research/connected-nations
- ONS Census: https://www.ons.gov.uk/census

## PIA Access
- Openreach PIA portal: https://d1reref.openreach.co.uk/cpportal/products/passive-products/physical-infrastructure-access(PIA)
- Ofcom DPA specification: https://www.ofcom.org.uk/__data/assets/pdf_file/0013/101542/duct-pole-access-report-mott-macdonald.pdf

## 3D Viewer / Maps
- Deck.gl: https://deck.gl/
- MapLibre GL JS: https://maplibre.org/
- OpenFreeMap tiles: https://tiles.openfreemap.org/
- SRTM elevation: https://dwtkns.com/srtm30m/

## Propagation References
- 3GPP TR 38.901: https://www.3gpp.org/DynaReport/38901.htm
- ITU-R P.2109 (BEL): https://www.itu.int/rec/R-REC-P.2109
- ITU-R P.838 (rain): https://www.itu.int/rec/R-REC-P.838

