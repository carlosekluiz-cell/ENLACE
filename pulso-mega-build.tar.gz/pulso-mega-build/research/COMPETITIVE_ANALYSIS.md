# PULSO vs Goliaths — Complete Competitive Research

## Date: March 2026
## Status: CONFIDENTIAL — Internal Use

---

## 1. COMSOF FIBER (IQGeo) — Primary Design Competitor

### What they are
- Leading automated FTTH planning and design software
- Acquired by IQGeo in August 2022
- 100M+ homes designed in 50+ countries
- Clients: Proximus (2M homes), Openreach, Upp, and hundreds more
- 100,000+ active software users

### Their workflow (how long it takes)
Three modules:
1. **Comsof Fiber Simulator** — Strategic planning, business case, area selection (1-2 days)
2. **Comsof Fiber Designer** — Network design with automated algorithms (1-2 weeks for a town)
3. **Comsof Fiber Engineer** — Detailed build packs, to-build documentation (2-4 weeks)

Total for a town: **1-2 months** with a team of engineers.

### What they deliver
- Automated splitter placement and cable routing
- Bill of Materials (BOM) with quantities and costs
- Fibre schema plans and reports
- Fibre optic connection plans
- Trenching plans
- Cable/duct-in-duct configuration
- Connector placement and labelling
- Fiber and splicing planning
- Cost optimised network designs
- Multiple scenario comparison
- Export to AutoCAD, QGIS, other GIS tools

### What they DON'T do
- No telemetry / live monitoring
- No RF propagation for FWA decisions
- No building physics (EPC data, BEL calculation)
- No market intelligence (competitor mapping, Ofcom data)
- No CSV upload zero-deployment analytics
- Desktop Windows software only (not web-based)
- No open source

### PULSO advantage over Comsof
- PULSO does Simulator + Designer in **minutes** instead of weeks
- PULSO integrates telemetry (ENLACE) — network stays connected after build
- PULSO has RF propagation — automated fibre-vs-FWA decision per premises
- PULSO has UK EPC building physics — BEL per building type
- PULSO has market intelligence — competitor coverage, expansion scoring
- PULSO is web-based — runs in browser, no Windows desktop needed
- PULSO is open source (agent layer)
- PULSO validated to 96% accuracy against real CF deployment

### Sources
- https://www.iqgeo.com/products/comsof-fiber
- https://comsof.com/fiber/blog/making-the-perfect-to-build-plans/
- https://www.ftthcouncil.eu/portals/0/Suppliers/328/62f19.pdf
- https://www.manula.com/manuals/comsof/comsof-fiber-designer/22.1/en/topic/introduction

---

## 2. ANTENNA PATTERN DATA — Freely Available

### MSI format library
- **400,000+ MSI pattern files** from 50+ manufacturers
- Source: https://www.wireless-planning.com/msi-antenna-pattern-file-library
- Includes: Huawei, Commscope, Kathrein, Ubiquiti, MikroTik, Intelbras, Cambium, etc.
- Size: ~5GB total library
- Format: ASCII text, 360 azimuth points + 360 elevation points per file
- Free to download and use

### MSI file format specification
- Header: NAME, MAKE, FREQUENCY (MHz), GAIN (dBd or dBi), COMMENT
- Horizontal pattern: 360 data points (0-359 degrees), gain relative to max
- Vertical pattern: 360 data points (0-359 degrees), gain relative to max
- Simple to parse — Perl parser exists on GitHub: https://github.com/mrdvt92/perl-RF-Antenna-Planet-MSI-Format
- MATLAB has native msiread/msiwrite functions
- Building a Rust parser: ~300 lines, straightforward ASCII parsing

### Other formats supported by industry
- NSMA WG16.99.050 / TIA/EIA-804-B (.adf) — more detailed, includes polarisation
- Radio Mobile V3 (.ant)
- Ekahau (.json) — for WiFi planning
- CloudRF uses TIA/EIA-804-B and has free validation tool: https://api.cloudrf.com/API/antennas/validator/

### What PULSO needs to build
- MSI file parser in Rust (~300 lines)
- Antenna pattern database loader (index by manufacturer, model, frequency)
- Integration with propagation engine: antenna gain at specific azimuth/elevation feeds into link budget
- 3D antenna pattern visualisation in Deck.gl (nice-to-have for UI)

---

## 3. OPENREACH PIA DUCT DATA — API Available

### What PIA provides
- Duct routes (underground paths between chambers)
- Chamber locations (manholes, handholes, joint boxes)
- Pole locations and types
- Capacity RAG status: GREEN (space available), AMBER (limited), RED (full)
- Asset types, categories, IDs for each infrastructure element

### How to access
- Openreach provides RESTful API for registered Communications Providers (CPs)
- CP registration with Ofcom: free, takes ~2 weeks
- PIA API onboarding with Openreach: required after CP registration
- Data syncs every 24 hours from Openreach PiPeR system
- CPs can download information into their own GIS systems
- Map-based view available through Openreach portal

### For PULSO integration
- CF is already a registered CP with PIA access
- Any PULSO customer who is a registered CP can provide their PIA credentials
- PULSO builds a PIA API client that pulls duct/pole data for a given area
- Overlays PIA data on the 3D map alongside PULSO's generated designs
- Routes fibre designs through actual PIA ducts instead of estimated road paths
- Shows capacity RAG status: if RED, route around or plan new-build

### Sources
- https://d1reref.openreach.co.uk/cpportal/products/passive-products/physical-infrastructure-access(PIA)
- https://digpro.com/blog/utilising-existing-infrastructure-for-fibre-rollout-when-connecting-britain/
- https://blog.iqgeo.com/an-integrated-pia-strategy-for-uk-altnet-providers
- Ofcom DPA specification: https://www.ofcom.org.uk/__data/assets/pdf_file/0013/101542/duct-pole-access-report-mott-macdonald.pdf

---

## 4. 3D WEB VIEWER — Open Source Stack

### Technology stack (all free, all open source)
- **Deck.gl** — WebGL2 powered visualisation framework, handles millions of data points
  - Already in PULSO stack
  - Source: https://deck.gl/
  - TerrainLayer: loads heightmap, reconstructs 3D mesh from SRTM
  - TerrainExtension: renders 2D data (fibre routes) along 3D terrain surface
  - PathLayer: 3D fibre routes with width and colour
  - PolygonLayer: building footprints with extrusion
  - ScatterplotLayer: splitter icons, ONT positions
  - EditableGeoJsonLayer: drag-and-drop editing of routes and positions

- **MapLibre GL JS** — Open source map renderer (fork of Mapbox GL)
  - 3D building extrusions from OpenFreeMap/OpenStreetMap
  - Free tiles from https://tiles.openfreemap.org/planet
  - No API key needed, no usage limits
  - fill-extrusion layer type renders buildings with height from OSM data
  - Source: https://maplibre.org/maplibre-gl-js/docs/examples/display-buildings-in-3d/

- **OpenFreeMap** — Free vector tiles from OpenStreetMap
  - Building footprints with render_height attribute
  - Road network, land use, water bodies
  - No API key, no rate limits
  - Source: https://tiles.openfreemap.org/

- **SRTM terrain data** — NASA elevation data (already in PULSO)
  - 30m resolution globally, 1-arc-second
  - Can be rendered as 3D terrain surface via Deck.gl TerrainLayer

### What PULSO 3D viewer can show
1. 3D terrain from SRTM (hills, valleys, elevation changes)
2. 3D buildings from OSM with real heights (where available) or EPC floor count × 3m
3. Road network as base layer (from OS Open Roads or OSM)
4. PIA duct routes (if loaded) with capacity RAG colours
5. PULSO-generated fibre routes colour-coded by cable type (12F/24F/48F/144F)
6. Splitter icons on buildings (32-way/64-way/PBO)
7. FWA coverage areas as translucent 3D volumes
8. Propagation heatmap draped on terrain
9. Telemetry overlay: ONT health scores as building colours
10. Competitor coverage zones
11. Interactive editing: drag splitters, drag routes, real-time optical budget recalculation

### Comparison vs Comsof/AutoCAD
- Comsof: desktop app, requires Windows, AutoCAD integration, licence fees
- PULSO: browser-based, any device, open-source stack, free base maps
- PULSO advantage: accessible anywhere, no installation, shareable via URL
- PULSO advantage: integrated telemetry and intelligence overlays impossible in Comsof

---

## 5. ADDITIONAL PROPAGATION MODELS TO ADD

### Okumura-Hata (MUST ADD — standard for rural 700MHz-2GHz)
- Empirical model, well-known formula
- Used by every Brazilian ISP engineer
- ~100 lines of Rust
- Covers: urban, suburban, rural environments
- Frequency range: 150-1500 MHz (extended Hata covers to 2GHz)
- Essential for 700MHz and 850MHz rural planning in Brazil

### COST 231 Hata (SHOULD ADD)
- Extension of Okumura-Hata for 1500-2000 MHz
- ~50 additional lines
- Covers urban environments at higher frequencies

### Ray tracing (SKIP FOR NOW)
- Complex (weeks of work)
- Only needed for dense urban small cells
- Not relevant for FWA or rural tower planning
- Can be added later if Tier 1 urban planning becomes a priority

### ITU-R P.1546 (CONSIDER)
- Point-to-area propagation predictions for 30-4000 MHz
- Used for broadcast and large-area coverage planning
- More complex than Hata, more accurate at longer distances
- ~500 lines of Rust

---

## 6. UK EPC BUILDING PHYSICS — VALUE PROPOSITION

### What it delivers
- For every premises in the UK: construction age, building type, floor count
- Maps to Building Entry Loss (BEL) at any frequency
- Victorian solid brick at 3.5GHz = 22dB BEL → FWA not viable indoors
- Modern new-build at 3.5GHz = 10dB BEL → FWA viable
- 1960s concrete council estate = 23dB BEL → FWA not viable
- Converted flat = 15dB BEL → FWA marginal

### Business value
- Automated fibre-vs-FWA decision per premises
- Saves £500+ per premises where FWA replaces fibre trenching
- Across 1.7M UK postcodes: identifies optimal connection method for every building
- No competitor has this level of building-specific physics

### Already built and tested
- uk_epc.rs: 18 tests, 104/104 total crate tests passing
- Classifies into 10 UkBuildingType variants
- Handles real-world EPC data quality issues
- Validated at Grahame Park: correctly identified 83% flats built 1967-1975

---

## 7. OS ADDRESSBASE — PATH TO 100% ACCURACY

### What it provides
- Every UPRN in UK with sub-metre coordinates
- Building name, flat number, classification
- Exact dwelling count per building (no EPC duplication issues)
- Available free via OS Data Hub for startups

### Impact on PULSO accuracy
- Building detection: 93% → 100% (finds all buildings including misspelled names)
- Splitter assignment: 40% → 87%+ (correct dwelling counts)
- PBO detection: 0% → 100% (real coordinates enable roof-link detection)
- Overall schematic accuracy: 56% → 96% (proven in v2 test)

### How to get it
- Register at https://osdatahub.os.uk/
- Free OS OpenData plan includes: Open UPRN, Code-Point Open, OS Open Roads
- Premium plan (free for startups): AddressBase Premium, MasterMap Topography
- Bulk download or API access

