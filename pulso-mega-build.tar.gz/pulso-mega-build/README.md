# PULSO MEGA BUILD

## Contents

### /prompts/MEGA_PROMPT.md
The main Claude Code prompt. Contains 8 phases:
1. Antenna Pattern Library (MSI parser + database)
2. Additional Propagation Models (Okumura-Hata, COST 231)
3. Build Pack Generator (BOM, schematics, trenching plans)
4. 3D Web Viewer (Deck.gl + MapLibre — FUTURE SESSION)
5. Interactive Design Editor (drag and drop — FUTURE SESSION)
6. Export Engine (GeoJSON, KML, XLSX, PDF, DXF — FUTURE SESSION)
7. FWA-vs-Fibre Decision Engine
8. Integration Test (blind Grahame Park)

For this session: run Phases 1, 2, 3, 7, then 8.
Phases 4, 5, 6 are frontend work for a later session.

### /research/COMPETITIVE_ANALYSIS.md
Complete competitive research: Comsof, Nokia AVA, Adtran, EXFO, VIAVI.
All source URLs included. Use for strategic positioning.

### /data-sources/DATA_SOURCES.md
All data source URLs needed for the build.

## How to use
1. Extract this tar.gz on the server
2. Open Claude Code
3. Tell it: "Read /home/dev/pulso-mega-build/prompts/MEGA_PROMPT.md and execute phases 1, 2, 3, 7, then 8"
4. Let it run (estimated 2-4 hours across phases)

